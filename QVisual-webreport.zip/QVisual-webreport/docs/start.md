Проект создан на основе [CRA](https://github.com/facebookincubator/create-react-app), а в качестве компонентов UI используется [material-ui](https://material-ui-1dab0.firebaseapp.com).

# Как запустить
Для запуска приложения потребуются установленные node и npm.
Далее заходим в проект и устанавливаем зависимости
```{r, engine='bash', deploy}
npm i
```

После их установки в проекте из командной строки достаточно выполнить:
```{r, engine='bash', deploy}
npm run build
server -s path_to_build
```

Так как это CRA, то возможен запуск development режима:
```{r, engine='bash', deploy}
npm run start
```

За другими способами деплоя можно обратиться [к документации CRA](https://github.com/facebookincubator/create-react-app/blob/master/packages/react-scripts/template/README.md#deployment).

# Переменные окружения
+ REACT_APP_API - устанавливает адрес API (по умолчанию - http://localhost:8081)