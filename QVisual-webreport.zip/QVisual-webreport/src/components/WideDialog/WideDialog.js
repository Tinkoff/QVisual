import React, { Component } from 'react';
import { createMuiTheme, MuiThemeProvider } from '@material-ui/core/styles';

import Dialog from '@material-ui/core/Dialog';

const theme = createMuiTheme({
    overrides: {
        MuiDialog: {
            paperWidthSm: {
                maxWidth: '100%'
            }
        }
    }
});

class WideDialog extends Component {
    render() {
        return (
            <MuiThemeProvider theme={theme}>
                <Dialog {...this.props}>{this.props.children}</Dialog>
            </MuiThemeProvider>
        );
    }
}

export default WideDialog;
