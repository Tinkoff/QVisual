import * as React from "react"
import { withStyles, WithStyles, StyleRules } from '@material-ui/core/styles';
import { compose } from 'redux';
import { connect } from 'react-redux';
import { ApplicationState } from '../../types';
import { Grid } from "@material-ui/core";
import Toolbar from "../Toolbar/ToolbarContainer";
import Snapshots from "./Snapshots";
import Board from "./Board";

const ToolbarContainer = Toolbar as any;

interface Props {
  match: any;
  showSnapshot: boolean;
}

const styles = theme => ({
  container: {
    height: `calc(100vh - ${`${theme.mixins.toolbar.minHeight * 2.5}px`})`
  }
});

class Main extends React.Component<Props & WithStyles<typeof styles>> {
  render() {
    const { showSnapshot, classes } = this.props;
    return <Grid className={classes.container} container spacing={0}>
      <ToolbarContainer enableEnvFilter enableShowErrorFilter enableReload />
      {
        showSnapshot && <Snapshots key='snapshots' />
      }
      {
        !showSnapshot && <Board key='board' />
      }
    </Grid>;
  }
}

const mapStateToProps = ({ board: { showSnapshot } }: ApplicationState, { match }) => {
  return {
    match,
    showSnapshot
  };
}

const mapDispatchToProps = {

}
export default compose<Props>(connect(mapStateToProps, mapDispatchToProps), withStyles(styles))(Main);
