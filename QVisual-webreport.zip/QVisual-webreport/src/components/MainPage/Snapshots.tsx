import * as React from 'react';
import { compose } from 'redux';
import { connect } from 'react-redux';
import { withStyles } from '@material-ui/core/styles';

// components
import Grid from '@material-ui/core/Grid';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import SnapshotDiff from '../Snapshot/SnapshotDiff';
import { selectDiffItemByName } from '../reducers/storiesFilter';
import { getReactKey, byPriorities } from '../../utils/snapshot';
import { ApplicationState } from '../../types';

import pathOr from '@tinkoff/utils/object/pathOr';

const styles = theme => ({
    tabsWrapper: {
        marginBottom: theme.spacing.unit + 4
    },
    toolbarWithTabs: {
        backgroundColor: theme.palette.common.white
    },
    tabs: {
        '& button': {
            height: 'auto'
        }
    },
    hideCtrl: {
        display: 'none'
    },
    snapshot: {
        overflow: 'auto'
    },
});

interface StateProps {
    classes?: any,
    disableDiffs: boolean,
    pixels?: string,
    visibility: string,
    diffsVisibility: any[],
    errorVisibility: any[],
    selectedDiffItem: string,
    snapshots: any,
    selectedSnapshotIndex: number,
}

interface DispatchProps {
    selectDiffItemByName: any,
    selectTab: any,
}

class Snapshots extends React.Component<StateProps & DispatchProps> {
    render() {
        const {
            classes,
            visibility,
            disableDiffs,
            pixels,
            diffsVisibility,
            errorVisibility,
            selectDiffItemByName,
            selectedDiffItem,
            snapshots,
            selectedSnapshotIndex
        } = this.props;

        const renderedSnapshots = snapshots.map((snapshot, index) => {
            const isVisible = selectedSnapshotIndex === index;
            const { images } = snapshot;

            const reactKey = getReactKey(snapshot);
            if (snapshot.error && !images.actual && !images.expected) {
                return (
                    <Grid key={reactKey} className={isVisible ? '' : classes.hideCtrl} xs={6} item>
                        {snapshot.error}
                    </Grid>
                );
            }

            return (
                <Grid
                    className={isVisible ? '' : classes.hideCtrl}
                    key={reactKey}
                    item
                    // xs={this.props.visibility !== 'all' ? 6 : 12}
                    xs={12}
                >
                    {isVisible && (
                        <Grid container spacing={0}>
                            <Grid item xs={12}>
                                <SnapshotDiff
                                    snapshot={snapshots[index]}
                                    disableDiffs={disableDiffs}
                                    pixels={pixels}
                                    visibility={visibility}
                                    diffsVisibility={diffsVisibility}
                                    errorVisibility={errorVisibility}
                                    selectDiffItemByName={selectDiffItemByName}
                                    selectedDiffItem={selectedDiffItem}
                                />
                            </Grid>
                        </Grid>
                    )}
                </Grid>
            );
        });

        return (
            <List>
                <ListItem className={classes.snapshot}>
                    <Grid container>{renderedSnapshots}</Grid>
                </ListItem>
            </List>
        );
    }
}

const mapStateToProps = ({ storiesFilter, stories: { currentSnapshotIndex, filteredStories, currentStateIndex, currentStoryIndex } }: ApplicationState) => ({
    disableDiffs: storiesFilter.disableDiffs,
    pixels: storiesFilter.pixels,
    visibility: storiesFilter.visibility,
    diffsVisibility: storiesFilter.diffsVisibility,
    errorVisibility: storiesFilter.errorVisibility,
    selectedDiffItem: storiesFilter.selectedDiff,
    snapshots: pathOr([currentStoryIndex, 'states', currentStateIndex, 'snapshots'], [], filteredStories),
    selectedSnapshotIndex: currentSnapshotIndex
} as StateProps);

const mapDispatchToProps = {
    selectDiffItemByName
} as DispatchProps;

export default compose(connect(mapStateToProps, mapDispatchToProps), withStyles(styles))(Snapshots);
