import { StyleRules, withStyles, WithStyles } from '@material-ui/core/styles';
import * as React from "react";
import { connect } from 'react-redux';
import { compose } from 'redux';
import { ApplicationState, Snapshot, SnapshotStatistic, State, StoriesFilterState, Story } from '../../types';
import { switchBoard } from "../reducers/boardReducer";
import { selectSnapshot, selectState, selectStory } from "../reducers/storyReducer";
import SnapshotInfo from "../Snapshot/SnapshotInfo";
import { StateDescription } from "../Toolbar/StoryNavigation";
import ScrollList from "./ScrollList";
import pathOr from '@tinkoff/utils/object/pathOr';

interface DispatchFunctions {
  selectState: (id: string) => void;
  selectStory: (id: string) => void;
  selectSnapshot: (id: string) => void;
  switchBoard: () => void;
}

interface MapStateProps {
  stories: Story[];
  currentStoryIndex: number;
  currentStateIndex: number;
  currentSnapshotIndex: number;
}

const styles = theme => ({
  wrapper: {
    width: '100%',
    '&>ul': {
      width: '40%'
    },
    '&>ul:last-child': {
      width: '19%'
    },
  },
  testCaseId: {
    display: 'block',
    fontSize: 11,
    color: '#9299A2'
  }
} as StyleRules);


class Board extends React.PureComponent<MapStateProps & DispatchFunctions & WithStyles<typeof styles>> {
  render() {
    const { classes, stories, currentStateIndex, currentStoryIndex, currentSnapshotIndex } = this.props;
    const currentStates = pathOr(['states'], [], stories[currentStoryIndex]);
    const currentSnapshots = pathOr(['snapshots'], [], currentStates[currentStateIndex]);

    return <div className={classes.wrapper}>
      <ScrollList
        onItemClick={this.handleStoryClick}
        title='Поиск по story'
        items={stories}
        renderItem={this.getName}
        activeIndex={currentStoryIndex}
        getItemTitle={this.getName}
      />
      <ScrollList
        onItemClick={this.handleStateClick}
        title='Поиск по state'
        items={currentStates}
        renderItem={this.renderState}
        activeIndex={currentStateIndex}
        getItemTitle={this.getName}
      />
      <ScrollList
        onItemClick={this.handleSnapshotClick}
        items={currentSnapshots}
        renderItem={this.renderSnapshot}
        activeIndex={currentSnapshotIndex}
      />
    </div >
  }

  getName = <T extends { name: string }>(st: T) => st.name;
  renderState = (state: State) => <StateDescription state={state} testCaseClassName={this.props.classes.testCaseId} />;
  renderSnapshot = (snapshot: Snapshot) => <SnapshotInfo snapshot={snapshot} />;

  createClickHandler(handler, shouldSwitchBoard = false) {
    return e => {
      const id = e.currentTarget.dataset.id;
      e.preventDefault();
      handler(id);
      if (shouldSwitchBoard)
        this.props.switchBoard();
    }
  }

  handleStoryClick = this.createClickHandler(this.props.selectStory);
  handleStateClick = this.createClickHandler(this.props.selectState);
  handleSnapshotClick = this.createClickHandler(this.props.selectSnapshot, true);
}

const mapStateToProps = ({ stories: { filteredStories, currentSnapshotIndex, currentStateIndex, currentStoryIndex }, }: ApplicationState): MapStateProps => {
  return {
    stories: filteredStories,
    currentSnapshotIndex,
    currentStateIndex,
    currentStoryIndex
  };
}

const mapDispatchToProps: DispatchFunctions = {
  selectState,
  selectStory,
  selectSnapshot,
  switchBoard
}

export default compose(connect(mapStateToProps, mapDispatchToProps), withStyles(styles))(Board);
