import * as React from "react"
import { withStyles, WithStyles } from '@material-ui/core/styles';
import { List, ListItem, ListItemText, ListSubheader, TextField } from "@material-ui/core";

interface ScrollListProps<T = any> {
  onItemClick: (event) => void;
  renderItem: (item: T) => React.ReactNode;
  getItemTitle?: (item: T) => string;
  activeIndex: number;
  items: T[];
  title: string;
  classes?: any;
}
interface State<T = any> {
  titleSubstring: string,
}

const styles = {
  listRoot: {
    overflow: 'scroll',
    display: 'inline-block',
    height: '100%',
    verticalAlign: 'top',
    backgroundColor: '#EEF2F7',
    borderRight: '2px solid #DDDFE0',
    color: '#454C54'
  },
  listItem: {
    overflow: 'auto',
    fontSize: 14,
    color: '#454C54'
  },
  activeListItem: {
    backgroundColor: '#FFFFFF',
    borderLeft: '3px solid #75a2c7',
    fontSize: 14,
    color: '#454C54'
  },
  withError: {
    overflow: 'auto',
    fontSize: 14,
    color: '#CD5C5C'
  }
};

class ScrollListPure<T extends { failed?: any, id?: string }> extends React.PureComponent<ScrollListProps<T> & WithStyles<any>, State<T>> {
  constructor(props) {
    super(props);
    this.state = {
      titleSubstring: '',
    };
  }

  handleChange = e => this.setState({ titleSubstring: e.target.value })
  render() {
    const { classes, renderItem, title, onItemClick, activeIndex, getItemTitle, items } = this.props;
    const { titleSubstring } = this.state;
    const withTitleFilter = !!getItemTitle;
    const filtered = getItemTitle
      ? items.filter(item => getItemTitle(item).match(new RegExp(titleSubstring, 'i')))
      : items;

    return <List className={classes.listRoot}>
      <ListSubheader>
        {
          withTitleFilter ?
            <TextField
              label={title}
              type='search'
              value={titleSubstring}
              fullWidth
              className={classes.textField}
              margin="normal"
              onChange={this.handleChange} />
            : title
        }

      </ListSubheader>
      {
        filtered.map((item, i) => (
          <ScrollListItem
            key={item.id || i}
            onItemClick={onItemClick}
            isActive={i === activeIndex}
            item={item}
            classes={classes}
            renderItem={renderItem}
          />
        ))
      }
    </List>
  }
}

class ScrollListItem extends React.PureComponent<any> {
  render() {
    const { onItemClick, isActive, item, classes, renderItem } = this.props;
    return (
      <ListItem button
        onClick={onItemClick}
        className={isActive ? classes.activeListItem : ''}
        data-id={item.id}>
        <ListItemText>
          <span className={item.failed ? classes.withError : classes.listItem}>
            {renderItem(item)}
          </span>
        </ListItemText>
      </ListItem>
    )
  }
}

export default withStyles(styles)(ScrollListPure);