import React from 'react';
import redColor from '@material-ui/core/colors/red';
import styles from './SvgDiff.css';

const SvgDiff = props => {
    const {
        left,
        top,
        width,
        height,
        diff,
        imageSource,
        disableDiffs,
        showPixels,
        name,
        handleClick,
        isSelected,
        useId
    } = props;
    const strokeWidth = 2;
    const dimensionCorrection = strokeWidth + 1;
    const imageShown = imageSource && !disableDiffs && showPixels;

    return (
        <g id={useId} width={width + dimensionCorrection} height={height + dimensionCorrection} onClick={handleClick}>
            {imageShown && (
                <defs>
                    <clipPath id={`${btoa(name)}`}>
                        <rect x={left} y={top} width={width} height={height} />
                    </clipPath>
                </defs>
            )}
            <title>
                Name:{'\n'}
                {name}
                {'\n'}
                {'\n'}
                Diff types:{'\n'}
                {diff.join('\n')}
            </title>
            {imageShown && (
                <image
                    className={styles.noClicks}
                    clipPath={`url(#${btoa(name)})`}
                    x={left}
                    y={top}
                    href={imageSource}
                />
            )}
            <rect
                x={left}
                y={top}
                width={width}
                height={height}
                strokeWidth={`0.3%`}
                fillOpacity="0.3"
                fill={isSelected ? redColor[600] : 'none'}
                stroke={redColor[300]}
            />
        </g>
    );
};

export default SvgDiff;
