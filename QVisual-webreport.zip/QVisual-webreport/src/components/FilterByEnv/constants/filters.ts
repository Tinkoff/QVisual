export const SKIP_FILTER = 'other';
export const RESOLUTIONS = [SKIP_FILTER, '320', '480', '768', '1024', '1440', '1366', '1920'];
export const BROWSERS = [SKIP_FILTER, 'chrome', 'safari', 'firefox'];
export const ENVIRONMENTS = [SKIP_FILTER, 'windows', 'vista', 'mac', 'android', 'ios'];
