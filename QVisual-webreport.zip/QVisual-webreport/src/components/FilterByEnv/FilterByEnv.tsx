import * as React from 'react';
import { connect } from 'react-redux';
import { withStyles, StyleRules } from '@material-ui/core/styles';
import { setEnvFilter, setBrowserFilter, setResolutionFilter } from '../reducers/storiesFilter';

//icons
import Menu from '@material-ui/icons/Menu';

// components
import Tooltip from '@material-ui/core/Tooltip';
import Button from '@material-ui/core/Button';
import Grid from '@material-ui/core/Grid';
import FormControl from '@material-ui/core/FormControl';
import FormLabel from '@material-ui/core/FormLabel';
import FormGroup from '@material-ui/core/FormGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import Dialog from '@material-ui/core/Dialog';

// utils
import updateFilterState from '../../utils/pureArrayUpdate';
import { RESOLUTIONS, BROWSERS, ENVIRONMENTS } from './constants/filters';

const styles = theme => ({
    popoverRoot: {
        padding: theme.spacing.unit * 2
    },
    niceOption: {
        textTransform: 'capitalize'
    },
    formFields: {
        '& > fieldset': {
            margin: `0 ${theme.spacing.unit * 3}px`
        },
        '& > fieldset:first-child': {
            margin: `0 ${theme.spacing.unit * 3}px 0 0`
        },
        '& > fieldset:last-child': {
            margin: `0 0 0 ${theme.spacing.unit * 3}px`
        }
    },
    btnWrapper: {
        fill: '#75A3C6',
        color: '#75A3C6',
        display: 'flex',
        flexFlow: 'row wrap',
        alignItems: 'center',
        justifyItems: 'stretch',
        margin: `${theme.spacing.unit}px 0`
    },
    buttonCtrl: {
        fontSize: 12
    },
    notActive: {
        fill: '#DDDFE0',
        color: '#DDDFE0'
    },
    darkTooltip: {
        background: '#3E4756',
        fontSize: 12
    }
} as StyleRules);

class FilterByEnv extends React.Component<Props & DispatchFunc> {
    state = {
        filterOpened: false
    };

    handleFilterOpen = () => {
        this.setState({ filterOpened: !this.state.filterOpened });
    };

    handleFilterCheck = (filterName, filterValue) => () => {
        const action = this.getFilterAction(filterName);
        const updated = updateFilterState(this.props[filterName], filterValue);

        action(updated);
    };

    getFilterAction = filterName => {
        switch (filterName) {
            case 'environment':
                return this.props.setEnvFilter;
            case 'browser':
                return this.props.setBrowserFilter;
            case 'resolutions':
                return this.props.setResolutionFilter;
            default:
        }
    };

    isChecked = (filterName, value) => {
        return this.props[filterName].indexOf(value) !== -1;
    };

    renderOptions(type, options) {
        return options.map(item => (
            <FormControlLabel
                key={item}
                className={this.props.classes.niceOption}
                label={item}
                control={
                    <Checkbox
                        checked={this.isChecked(type, item)}
                        onChange={this.handleFilterCheck(type, item)}
                        value={item}
                        disableRipple
                    />
                }
            />
        ));
    }

    render() {
        const { classes, disabled } = this.props;

        return (
            <span className={classes.btnWrapper}>
                <Tooltip
                    title="Фильтр по параметрам браузера"
                    placement="bottom-start"
                    classes={{ tooltip: classes.darkTooltip }}
                >
                    <Button
                        className={classes.notActive}
                        disabled={disabled}
                        onClick={this.handleFilterOpen}
                        component="a"
                        size="small"
                        disableRipple
                    >
                        <Menu />
                    </Button>
                </Tooltip>

                <Dialog open={this.state.filterOpened} onClose={this.handleFilterOpen}>
                    <Grid className={classes.popoverRoot} container>
                        <Grid className={classes.formFields} item xs>
                            <FormControl component="fieldset">
                                <FormLabel component="legend">Environment</FormLabel>
                                <FormGroup>
                                    {this.renderOptions('environment', ENVIRONMENTS)}
                                </FormGroup>
                            </FormControl>

                            <FormControl component="fieldset">
                                <FormLabel component="legend">Browser</FormLabel>
                                <FormGroup>{this.renderOptions('browser', BROWSERS)}</FormGroup>
                            </FormControl>

                            <FormControl component="fieldset">
                                <FormLabel component="legend">Resolutions</FormLabel>
                                <FormGroup>
                                    {this.renderOptions('resolutions', RESOLUTIONS)}
                                </FormGroup>
                            </FormControl>
                        </Grid>
                    </Grid>
                </Dialog>
            </span>
        );
    }
}

interface Props {
    classes: any,
    environment: any[],
    browser: any[],
    resolutions: any[],
    disabled: boolean
};

interface DispatchFunc {
    setEnvFilter: typeof setEnvFilter,
    setBrowserFilter: typeof setBrowserFilter,
    setResolutionFilter: typeof setResolutionFilter,
}


(FilterByEnv as any).defaultProps = {
    disabled: false
};

const mapStateToProps = ({ storiesFilter }) => ({
    environment: storiesFilter.environment,
    browser: storiesFilter.browser,
    resolutions: storiesFilter.resolutions
});

const mapDispatchToProps = {
    setEnvFilter,
    setBrowserFilter,
    setResolutionFilter,
} as DispatchFunc;

export default connect(mapStateToProps, mapDispatchToProps)(withStyles(styles)(FilterByEnv));
