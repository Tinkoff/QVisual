import React, { Component } from 'react';
import pt from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import Paper from '@material-ui/core/Paper';
import SvgDiff from '../SvgDiff/SvgDiff';
import { VISIBILITY, DISPLAYED_DIFF_TYPES, DIFF_VISIBILITY_FILTERS, DISPLAY_TO_KEY } from './constants/filters';

const styles = theme => ({
    paper: {
        backgroundColor: '#EEF2F7',
        overflow: 'hidden',
        position: 'relative',
        textAlign: 'center',
        lineHeight: 0,
        borderRadius: '0 !important'
    },
    snapshotImage: {
        boxSizing: 'border-box',
        maxWidth: '100%'
    },
    pixelImage: {
        maxWidth: '100%',
        display: 'block'
    },
    portalWithSvg: {
        position: 'absolute',
        overflow: 'hidden',
        left: '50%',
        transform: 'translate(-50%)',
        top: 0,
        zIndex: theme.zIndex.mobileStepper,
        '& svg rect:hover': {
            strokeWidth: '0.45%'
        }
    }
});

class SnapshotItem extends Component {
    state = {
        isDiffShown: true
    };

    constructor(props) {
        super(props);

        this.handleActualZoomEnd = this.handleZoomEnd('image', 'svg', 'pixels');
        this.handleActualZoom = this.handleZoom('image', 'svg', 'pixels');
    }

    componentWillUnmount() {
        this.image = null;
        this.svg = null;
        this.pixels = null;
    }

    flattenDiffs = diffsArray => {
        const { disableDiffs, showPixels } = this.props;

        if (disableDiffs) return null;

        // TODO: избавиться от parentProps, хотя бы частично
        const diffs = [];
        const parentProps = { disableDiffs, showPixels };

        this.props.diffsVisibility.map(key => {
            if (!diffsArray[key] || !diffsArray[key].length) {
                return null;
            }

            // фильтруем для рендера displayed элементы по типу ошибки (свойство diff)
            if (key === DISPLAY_TO_KEY.displayed) {
                return diffsArray[key].forEach(props => {
                    const hasDiff = props.diff.some(type => this.props.errorVisibility.indexOf(type) > -1);

                    if (hasDiff) {
                        return diffs.push(<SvgDiff {...props} {...parentProps} />);
                    }
                });
            }

            const svgs = diffsArray[key].map(props => <SvgDiff {...props} {...parentProps} />);

            return diffs.push(...svgs);
        });

        return diffs;
    };

    beginZoom = (reference, event) => {
        const { isZoomEnabled, zoomLevel } = this.props;

        if (!isZoomEnabled || zoomLevel === 1 || !this[reference]) {
            return;
        }

        const area = this[reference].getBoundingClientRect();

        const dx = (event.pageX - area.left) / area.width * 100;
        const dy = (event.pageY - area.top) / area.height * 100;

        this[reference].style.transform = `scale(${zoomLevel})`;
        this[reference].style.transformOrigin = `${dx}% ${dy}%`;
    };

    finishZoom = reference => {
        const { isZoomEnabled, zoomLevel } = this.props;

        if (!isZoomEnabled || zoomLevel === 1 || !this[reference]) {
            return;
        }

        this[reference].style.transform = 'scale(1)';
    };

    handleZoom = (imgRef, svgRef, pixelRef) => event => {
        this.beginZoom(imgRef, event);
        this.beginZoom(svgRef, event);
        this.beginZoom(pixelRef, event);
    };

    handleZoomEnd = (imgRef, svgRef, pixelRef) => () => {
        this.finishZoom(imgRef);
        this.finishZoom(svgRef);
        this.finishZoom(pixelRef);
    };

    setRef = componentName => component => {
        this[componentName] = component;
    };

    handleImageLoad = () => {
        if (!this.image) {
            return;
        }

        this.props.onImageLoad(this.image);
    };

    render() {
        const {
            classes,
            disableDiffs,
            showPixels,
            naturalImageWidth,
            naturalImageHeight,
            imageSrc,
            isDiffShown,
            snapshot
        } = this.props;

        if (!imageSrc) {
            return null;
        }

        const isDiffHidden = !isDiffShown || disableDiffs;
        const { diffs, pixels } = snapshot;

        return (
            <Paper className={classes.paper} onMouseOut={this.handleActualZoomEnd} onMouseMove={this.handleActualZoom}>
                <img
                    ref={this.setRef('image')}
                    className={classes.snapshotImage}
                    onLoad={this.handleImageLoad}
                    src={imageSrc}
                    alt="Snapshot pic"
                />
                <div
                    className={classes.portalWithSvg}
                    style={{
                        display: isDiffShown ? 'block' : 'none',
                        width: '100%',
                        maxWidth: naturalImageWidth
                    }}
                >
                    {showPixels &&
                        disableDiffs && (
                            <img
                                className={classes.pixelImage}
                                ref={this.setRef('pixels')}
                                src={pixels}
                                alt="Pixel Diff"
                            />
                        )}
                </div>
                <div
                    className={classes.portalWithSvg}
                    style={{
                        display: isDiffHidden ? 'none' : 'block',
                        width: '100%'
                    }}
                >
                    <svg
                        xmlns="http://www.w3.org/2000/svg"
                        ref={this.setRef('svg')}
                        viewBox={`0 0 ${naturalImageWidth} ${naturalImageHeight}`}
                        width="100%"
                        height="100%"
                        style={{
                            maxWidth: naturalImageWidth
                        }}
                    >
                        {diffs ? this.flattenDiffs(diffs) : null}
                    </svg>
                </div>
            </Paper>
        );
    }
}

SnapshotItem.propTypes = {
    classes: pt.object.isRequired,
    snapshot: pt.shape({
        diffs: pt.object,
        pixels: pt.string
    }),
    disableDiffs: pt.bool,
    isDiffShown: pt.bool,
    showPixels: pt.bool,
    naturalImageWidth: pt.number,
    naturalImageHeight: pt.number,
    imageSrc: pt.string,
    onImageLoad: pt.func,
    visibility: pt.oneOf(VISIBILITY),
    diffsVisibility: pt.arrayOf(pt.oneOf(DIFF_VISIBILITY_FILTERS)),
    errorVisibility: pt.arrayOf(pt.oneOf(DISPLAYED_DIFF_TYPES)),
    isZoomEnabled: pt.bool,
    zoomLevel: pt.number
};

export default withStyles(styles)(SnapshotItem);
