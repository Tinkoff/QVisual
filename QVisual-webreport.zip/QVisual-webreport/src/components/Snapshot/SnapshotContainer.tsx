import * as React from 'react';
import { connect } from 'react-redux';
import Snapshot from './Snapshot';
import { selectDiffItemByName } from '../reducers/storiesFilter';
import { ApplicationState, Snapshot as ISnapshot } from '../../types';
import path from '@tinkoff/utils/object/path';

class SnapshotContainer extends React.Component<OwnProps> {
    render() {
        return <Snapshot {...this.props} />;
    }
}

interface OwnProps {
    match: any;
    location: any;
}

interface ReduxState {
    snapshot?: ISnapshot,
    storyTitle?: string,
    stateTitle?: string,
    selectedDiffItem: string,
    disableDiffs: boolean,
    pixels: string,
    visibility: string,
    diffsVisibility: any[],
    errorVisibility: any[],
    zoomLevel: number,
    zoomEnabled: boolean,
    match: any,
};

interface Dispatch {
    selectDiffItemByName: (...args) => void,
}

(SnapshotContainer as any).defaultProps = {
    snapshot: {},
    storyTitle: '',
    stateTitle: ''
};
//TODO: перевести url на snapshotId 
const mapStateToProps = ({ stories: { stories, currentStoryIndex, currentSnapshotIndex, currentStateIndex }, storiesFilter, snapshot: snapshotState }: ApplicationState, ownProps: OwnProps): ReduxState => {
    const story = stories[currentStoryIndex];
    const state = path(['states', currentStateIndex], story);
    const snapshot = path(['snapshots', currentSnapshotIndex], state);

    const componentState = {
        disableDiffs: storiesFilter.disableDiffs,
        pixels: storiesFilter.pixels,
        visibility: storiesFilter.visibility,
        diffsVisibility: storiesFilter.diffsVisibility,
        errorVisibility: storiesFilter.errorVisibility,
        selectedDiffItem: storiesFilter.selectedDiff,
        zoomLevel: snapshotState.zoom,
        zoomEnabled: snapshotState.zoomEnabled,
        match: ownProps.match
    };

    return {
        stateTitle: state && state.name,
        storyTitle: story && story.name,
        snapshot,
        ...componentState
    };
};

const mapDispatchToProps = {
    selectDiffItemByName
} as Dispatch;

export default connect(mapStateToProps, mapDispatchToProps)(SnapshotContainer);
