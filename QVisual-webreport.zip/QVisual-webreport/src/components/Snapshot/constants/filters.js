export const ALL = 0;
export const ACTUAL = 1;
export const EXPECTED = 2;
export const VISIBILITY_FILTER = {
    all: ALL,
    actual: ACTUAL,
    expected: EXPECTED
};
export const VISIBILITY = ['all', 'actual', 'expected'];
export const DISPLAYED_DIFF_TYPES = ['image', 'moved', 'text', 'resized', 'attributes', 'css'];
export const DIFF_VISIBILITY_FILTERS = [
    'added',
    'removed',
    'displayed',
    'shouldBeDisplayed',
    'shouldNotBeDisplayed',
    'not found'
];
export const DISPLAY_TO_KEY = {
    added: 'added',
    removed: 'removed',
    displayed: 'displayed',
    'should be displayed': 'shouldBeDisplayed',
    'should not be displayed': 'shouldNotBeDisplayed',
    'not found': 'not found'
};
