export const ACTUAL_SNAPSHOT_NOT_FOUND = 'actual snapshot not found';
export const EXPECTED_SNAPSHOT_NOT_FOUND = 'expected snapshot not found';
export const ELEMENTS_NOT_PARSED = 'could not parse elements json';
export const ELEMENTS_NOT_FOUND = 'empty elements';
export const URLS_IMGS_NOT_FOUND = 'empty urls of images';
export const EMPTY_IMAGES = 'empty images';
export const SNAPSHOTS_NOT_FOUND = 'not found snapshots';
