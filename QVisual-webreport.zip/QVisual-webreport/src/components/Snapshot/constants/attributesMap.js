const AREA_COLUMNS = [
    { id: 'attr', numeric: false, label: 'Area' },
    { id: 'actual', numeric: false, label: 'Actual' },
    { id: 'expected', numeric: false, label: 'Expected' }
];

const ATTRIBUTE_COLUMNS = [
    { id: 'attr', numeric: false, label: 'Attributes' },
    { id: 'actual', numeric: false, label: 'Actual' },
    { id: 'expected', numeric: false, label: 'Expected' }
];

const CSS_COLUMNS = [
    { id: 'attr', numeric: false, label: 'CSS' },
    { id: 'actual', numeric: false, label: 'Actual' },
    { id: 'expected', numeric: false, label: 'Expected' }
];

const TEXT_COLUMNS = [
    { id: 'attr', numeric: false, label: 'Text' },
    { id: 'actual', numeric: false, label: 'Actual' },
    { id: 'expected', numeric: false, label: 'Expected' }
];

export default {
    area: {
        columns: AREA_COLUMNS,
        attributeName: 'area'
    },
    attributes: {
        columns: ATTRIBUTE_COLUMNS,
        attributeName: 'attributes'
    },
    css: {
        columns: CSS_COLUMNS,
        attributeName: 'css'
    },
    text: {
        columns: TEXT_COLUMNS,
        attributeName: 'text'
    }
};
