import React, { Component } from 'react';
import pt from 'prop-types';
import { compose } from 'redux';
import { withStyles } from '@material-ui/core/styles';

// components
import DiffTable from '../DiffTable/DiffTable';
import AttrDiffTable from '../DiffTable/AttrDiffTableContainer';
import AttrMap from './constants/attributesMap';
import Dialog from '../WideDialog/WideDialog';

import Card from '@material-ui/core/Card';
import CardHeader from '@material-ui/core/CardHeader';
import CardContent from '@material-ui/core/CardContent';
import Paper from '@material-ui/core/Paper';
import Typography from '@material-ui/core/Typography';
import Collapse from '@material-ui/core/Collapse';
import { DISPLAY_TO_KEY } from './constants/filters';

// material icons
import ExpandMore from '@material-ui/icons/ExpandMore';
import ExpandLess from '@material-ui/icons/ExpandLess';

const styles = () => ({
    noShadow: {
        boxShadow: 'none',
        backgroundColor: '#FFFFFF'
    },
    cardHeader: {
        wordBreak: 'break-all'
    },
    cardImage: {
        cursor: 'pointer',
        maxWidth: '100%'
    },
    cardImageZoomed: {
        display: 'block',
        height: 'auto',
        width: 'auto',
        maxWidth: '100%'
    },
    scroll: {
        overflow: 'auto'
    },
    openCtrl: {
        '&:hover': {
            backgroundColor: 'rgba(236, 239, 241, 0.3)'
        }
    }
});

class SnapshotAttrsBlock extends Component {
    state = {
        elements: [],
        opened: {},
        openedZoomed: ''
    };

    componentWillMount() {
        this.filterElements(this.props);
    }

    componentWillReceiveProps(nextProps) {
        const { snapshot, diffsVisibility, errorVisibility } = nextProps;
        if (
            snapshot !== this.props.snapshot ||
            diffsVisibility !== this.props.diffsVisibility ||
            errorVisibility !== this.props.errorVisibility
        ) {
            this.filterElements(nextProps);
        }

        if (this.props.parentRef && nextProps.selectedDiffItem !== this.props.selectedDiffItem) {
            this.scrollToCard(nextProps.selectedDiffItem);
        }
    }

    filterElements(props) {
        const { snapshot, diffsVisibility, errorVisibility } = props;

        if (snapshot && (snapshot.error || !snapshot.elements)) {
            return;
        }

        const newElements = snapshot.elements.filter(element => {
            const hasDisplayType = diffsVisibility.indexOf(DISPLAY_TO_KEY[element.display]) > -1;

            if (hasDisplayType && element.display !== 'displayed') {
                return true;
            }

            // только у типа 'displayed' могут быть ошибки из errorVisibility
            const hasErrorType = element.diff.some(type => errorVisibility.indexOf(type) > -1);

            return hasErrorType && hasDisplayType;
        });

        this.setState({ elements: newElements });
    }

    scrollToCard = name => {
        const element = document.getElementById(name);

        if (!element) {
            return;
        }

        this.props.parentRef.scrollTo(0, element.offsetTop);
    };

    selectDiffItem = event => {
        const name = event.currentTarget.getAttribute('href');

        event.preventDefault();
        this.props.selectDiffItemByName(name);
    };

    handleOpenCard = id => () => {
        let newOpenState = true;

        if (this.state.opened[id] === true) {
            newOpenState = false;
        }

        this.setState({
            opened: {
                ...this.state.opened,
                [id]: newOpenState
            }
        });
    };

    handleZoom = name => () => {
        this.setState({ openedZoomed: name });
    };

    handleZoomClose = () => {
        this.setState({ openedZoomed: '' });
    };

    render() {
        const { classes, snapshot } = this.props;
        const { elements } = this.state;
        if (!snapshot || !snapshot.elements || (snapshot && snapshot.error)) {
            return null;
        }

        return (
            <Paper className={classes.noShadow}>
                {elements.map((elem, key) => {
                    const isContentVisible = elem.diff.length > 0;
                    const name = `${DISPLAY_TO_KEY[elem.display]}-${elem.name}`;

                    return (
                        <Card className={classes.noShadow} key={elem.name} id={name}>
                            <CardContent>
                                <a href={name} onClick={this.selectDiffItem}>
                                    <CardHeader className={classes.cardHeader} title={elem.name} />
                                </a>

                                <CardContent>
                                    <Typography gutterBottom type="subheading">
                                        Diff types:
                                    </Typography>
                                    {elem.display !== DISPLAY_TO_KEY.displayed && (
                                        <Typography key={`display-${elem.display}`} type="body1">
                                            {elem.display}
                                        </Typography>
                                    )}
                                    {elem.diff.map(type => (
                                        <Typography key={type} type="body1">
                                            {type}
                                        </Typography>
                                    ))}
                                </CardContent>

                                {elem.image && (
                                    <CardContent>
                                        <img
                                            className={classes.cardImage}
                                            src={elem.image}
                                            alt={name}
                                            onClick={this.handleZoom(elem.name)}
                                        />
                                        <Dialog
                                            open={this.state.openedZoomed === elem.name}
                                            onClose={this.handleZoomClose}
                                        >
                                            <img className={classes.cardImageZoomed} src={elem.image} alt={name} />
                                        </Dialog>
                                    </CardContent>
                                )}

                                {isContentVisible && (
                                    <CardContent className={classes.openCtrl} onClick={this.handleOpenCard(key)}>
                                        {this.state.opened[key] ? <ExpandLess /> : <ExpandMore />}
                                    </CardContent>
                                )}

                                {isContentVisible && (
                                    <Collapse in={this.state.opened[key]} transitionAppear={false}>
                                        <CardContent className={classes.scroll}>
                                            <AttrDiffTable
                                                attributeName={AttrMap.area.attributeName}
                                                columns={AttrMap.area.columns}
                                                element={elem}
                                            />
                                        </CardContent>

                                        <CardContent className={classes.scroll}>
                                            <AttrDiffTable
                                                attributeName={AttrMap.attributes.attributeName}
                                                columns={AttrMap.attributes.columns}
                                                element={elem}
                                            />
                                        </CardContent>

                                        <CardContent className={classes.scroll}>
                                            <AttrDiffTable
                                                attributeName={AttrMap.css.attributeName}
                                                columns={AttrMap.css.columns}
                                                element={elem}
                                            />
                                        </CardContent>

                                        {elem.diff.includes('text') && (
                                            <CardContent className={classes.scroll}>
                                                <DiffTable columns={AttrMap.text.columns} body={[elem.text]} />
                                            </CardContent>
                                        )}
                                    </Collapse>
                                )}
                            </CardContent>
                        </Card>
                    );
                })}
            </Paper>
        );
    }
}

SnapshotAttrsBlock.propTypes = {
    classes: pt.object.isRequired,
    snapshot: pt.object.isRequired,
    selectDiffItemByName: pt.func,
    selectedDiffItem: pt.string,
    diffsVisibility: pt.array.isRequired,
    errorVisibility: pt.array.isRequired,
    parentRef: pt.object
};

SnapshotAttrsBlock.defaultProps = {
    selectDiffItemByName: () => {},
    selectedDiffItem: ''
};

export default compose(withStyles(styles))(SnapshotAttrsBlock);
