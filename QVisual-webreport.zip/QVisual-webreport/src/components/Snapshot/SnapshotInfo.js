import React, { Component } from 'react';
import pt from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import Typography from '@material-ui/core/Typography';
import SnapshotStatBlock from './SnapshotStatBlock';
import { getInfo } from '../../utils/snapshot';

const styles = () => ({
    header: {
        textAlign: 'left'
    },
    browser: {
        marginBottom: 6,
        color: '#3E4756',
        fontSize: 12,
        textTransform: 'lowercase'
    },
    blocks: {
        display: 'flex',
        justifyContent: 'flex-start'
    },
    titleWithErrors: {
        color: '#CD5C5C'
    }
});

class SnapshotInfo extends Component {
    componentWillMount() {
        getInfo(this.props);
    }

    componentWillReceiveProps(nextProps) {
        getInfo(nextProps);
    }

    render() {
        const { classes, snapshot } = this.props;

        if (!snapshot || !snapshot.browser) {
            return (
                <div className={classes.header}>
                    <Typography type="title">There is no info</Typography>
                </div>
            );
        }

        const pixels = snapshot.diffPercentage;
        const elements = snapshot.elements.length;
        const isError = !!snapshot.error;

        return (
            <div className={classes.header}>
                <Typography className={classes.browser} type="body">
                    {snapshot.browser.browserName}&nbsp;
                    {snapshot.browser.browserVersion}&nbsp;
                    {snapshot.browser.osName}&nbsp;
                    {snapshot.browser.resolution}&nbsp;
                    {snapshot.browser.retina}
                </Typography>
                <div className={classes.blocks}>
                    <SnapshotStatBlock title="pixels" value={pixels} isError={pixels > 0} />
                    <SnapshotStatBlock title="elements" value={elements} isError={elements > 0} />
                    <SnapshotStatBlock title="error" value={isError ? 1 : 0} isError={isError} />
                </div>
            </div>
        );
    }
}

SnapshotInfo.propTypes = {
    classes: pt.object.isRequired,
    snapshot: pt.object,
    storyTitle: pt.string,
    stateTitle: pt.string
};

SnapshotInfo.defaultProps = {
    snapshot: {},
    storyTitle: '',
    stateTitle: ''
};

export default withStyles(styles)(SnapshotInfo);
