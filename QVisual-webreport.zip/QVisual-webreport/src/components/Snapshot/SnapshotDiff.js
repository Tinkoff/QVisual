import React, { Component } from 'react';
import pt from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import cn from 'classnames';
import Grid from '@material-ui/core/Grid';
import SnapshotItem from './SnapshotItem';
import Dialog from '../WideDialog/WideDialog';
import Typography from '@material-ui/core/Typography';
import IconButton from '@material-ui/core/IconButton';
import ActualImg from '@material-ui/icons/CropOriginal';
import ExpectedImg from '@material-ui/icons/Photo';
import Fullscreen from '@material-ui/icons/Fullscreen';
import {
    ALL,
    ACTUAL,
    EXPECTED,
    VISIBILITY_FILTER,
    VISIBILITY,
    DISPLAYED_DIFF_TYPES,
    DIFF_VISIBILITY_FILTERS,
    DISPLAY_TO_KEY
} from './constants/filters';
import { URLS_IMGS_NOT_FOUND, EMPTY_IMAGES, SNAPSHOTS_NOT_FOUND } from './constants/errors';
import SnapshotStatBlock from './SnapshotStatBlock';
import { getSnapshotStats } from '../../utils/statsHelper';

const FIX_OS = ['windows', 'vista'];
const OMIT_STATS_KEY = ['pixels', 'total', 'error', 'errorsQuantity'];

const styles = theme => ({
    diffsWrapper: {
        position: 'relative',
        padding: 5
    },
    hideDiff: {
        visibility: 'hidden',
        position: 'absolute',
        left: -9999
    },
    withOverflow: {
        overflow: 'auto'
    },
    imageHeader: {
        display: 'flex',
        alignItems: 'center',
        marginTop: '4px',
        marginBottom: '10px'
    },
    title: {
        marginRight: '5px',
        marginLeft: '5px',
        fontSize: 12,
        fontWeight: 'normal',
        color: '#9299A2'
    },
    hideCtrl: {
        display: 'none'
    },
    smallIcon: {
        width: '30px',
        height: '30px'
    },
    statsWrapper: {
        fontFamily: 'Lato',
        padding: '5px 0px 14px 0px',
        borderBottom: '1px solid #DDDFE0'
    },
    diffWrapper: {
        display: 'flex'
    },
    expectedWithoutActual: {
        left: '50%'
    }
});

class SnapshotDiff extends Component {
    state = {
        isActualShowed: true,
        isExpectedShowed: true,
        diffs: {},
        diffsCreated: false,
        fullscreen: {
            actual: false,
            expected: false
        }
    };

    componentWillMount() {
        this.updateVisibilityFilter(VISIBILITY_FILTER[this.props.visibility]);
    }

    componentWillReceiveProps(nextProps) {
        if (this.props.selectedDiffItem !== nextProps.selectedDiffItem) {
            if (this.props.selectedDiffItem) {
                this.selectDiffByName(this.props.selectedDiffItem, false);
            }

            this.selectDiffByName(nextProps.selectedDiffItem, true);
        }

        this.updateVisibilityFilter(VISIBILITY_FILTER[nextProps.visibility]);
    }

    updateVisibilityFilter = filter => {
        const isActualShowed = filter === ALL || filter === ACTUAL;
        const isExpectedShowed = filter === ALL || filter === EXPECTED;

        if (this.state.isActualShowed !== isActualShowed || this.state.isExpectedShowed !== isExpectedShowed) {
            this.setState({ isActualShowed, isExpectedShowed, diffsCreated: false });
        }
    };

    createDiffElements = () => {
        const { elements } = this.props.snapshot;

        if (!elements) {
            return;
        }

        const diffs = {
            actual: {
                added: [],
                removed: [],
                displayed: [],
                shouldBeDisplayed: [],
                shouldNotBeDisplayed: []
            },
            expected: {
                added: [],
                removed: [],
                displayed: [],
                shouldBeDisplayed: [],
                shouldNotBeDisplayed: []
            }
        };

        elements.filter(element => element && element.display !== 'not found').forEach((element, key) => {
            const objKey = DISPLAY_TO_KEY[element.display];
            const suffix = `${objKey}-${element.name}`;
            const actualUsedId = `actual-${suffix}`;
            const expectedUsedId = `expected-${suffix}`;
            const imageSource = element.diff.includes('image') && element.image;

            const commonProps = {
                diff: element.display === DISPLAY_TO_KEY.displayed ? element.diff : [element.display],
                name: element.name,
                handleClick: this.handleSelectDiff(suffix),
                isSelected: this.props.selectedDiffItem === suffix
            };

            const actualSvg = {
                key: `actual-${key}`,
                useId: actualUsedId,
                imageSource,
                ...this.recalcElementArea(element, 'actual'),
                ...commonProps
            };

            const expectedSvg = {
                key: `expected-${key}`,
                useId: expectedUsedId,
                imageSource,
                ...this.recalcElementArea(element, 'expected'),
                ...commonProps
            };

            switch (element.display) {
                case 'added':
                    return diffs.actual[objKey].push(actualSvg);
                case 'removed':
                    return diffs.expected[objKey].push(expectedSvg);
                case 'not displayed':
                    break;
                case 'displayed':
                case 'should be displayed':
                case 'should not be displayed':
                    diffs.actual[objKey].push(actualSvg);
                    diffs.expected[objKey].push(expectedSvg);
                    return;
                default:
            }
        });

        this.setState({
            diffs,
            diffsCreated: true
        });
    };

    recalcElementArea(element, type) {
        const { browser } = this.props.snapshot;
        const { width, height, top, left } = element.area;

        // на бэке не правильно рассчитывается ширина diff'а (не учитывается ширина скролла)
        // из-за чего съезжает обводка
        const shouldFix = FIX_OS.some(os => os === browser.osName.toLowerCase());
        const areaWidth = shouldFix ? width[type] + 17 : width[type];
        const area = {
            left: left[type],
            top: top[type],
            width: areaWidth,
            height: height[type]
        };

        if (browser && browser.retina) {
            area.left *= 2;
            area.top *= 2;
            area.width *= 2;
            area.height *= 2;
        }

        return area;
    }

    handleSelectDiff = name => () => {
        const selectedItem = this.props.selectedDiffItem === name ? '' : name;

        this.props.selectDiffItemByName(selectedItem);
        this.selectDiffByName(name, selectedItem);

        if (selectedItem) {
            this.selectDiffByName(this.props.selectedDiffItem, false);
        }
    };

    selectDiffByName = (name, value) => {
        this.updateDiffByName('actual', { name, prop: 'isSelected', value });
        this.updateDiffByName('expected', { name, prop: 'isSelected', value });
    };

    updateDiffByName = (type, { name, prop, value }) => {
        const idx = name.search('-');
        const displayType = name.slice(0, idx);
        const diffName = name.slice(idx + 1);
        const diffs = this.state.diffs[type][displayType];

        if (!diffs) {
            return;
        }

        const newDiffs = diffs.slice();

        for (let i = 0; i < newDiffs.length; i++) {
            if (newDiffs[i].name === diffName) {
                newDiffs[i][prop] = value;
                break;
            }
        }

        this.setState({
            diffs: {
                ...this.state.diffs,
                [type]: {
                    ...this.state.diffs[type],
                    [displayType]: newDiffs
                }
            }
        });
    };

    handleActualImg = reference => {
        this.calculateImgArea(reference, 'actual');
    };

    handleExpectedImg = reference => {
        this.calculateImgArea(reference, 'expected');
    };

    calculateImgArea = (reference, imgType) => {
        if (!reference) {
            return;
        }

        this.setState({
            [`${imgType}NaturalImageWidth`]: reference.naturalWidth || 0,
            [`${imgType}NaturalImageHeight`]: reference.naturalHeight || 0
        });
        this.createDiffElements();
    };

    handleFullscreen = event => {
        const { type } = event.currentTarget.dataset;
        const fullscreen = this.state.fullscreen;

        fullscreen[type] = true;
        this.setState({ fullscreen });
    };

    handleFullscreenOff = () => {
        const fullscreen = {
            actual: false,
            expected: false
        };

        this.setState({ fullscreen });
    };

    renderHeader(type) {
        const { classes, snapshot } = this.props;
        const { server, branch, commit } = snapshot;

        return (
            <Grid container spacing={0}>
                <Grid item xs>
                    <div className={classes.imageHeader}>
                        {type === 'actual' ? <ActualImg /> : <ExpectedImg />}
                        <IconButton className={classes.smallIcon} disableRipple>
                            <Fullscreen onClick={this.handleFullscreen} data-type={type} />
                        </IconButton>
                        {server[type] && (
                            <Typography className={classes.title} type="subheading">
                                server: {server[type]}
                            </Typography>
                        )}
                        {branch[type] && (
                            <Typography className={classes.title} type="subheading">
                                branch: {branch[type]}
                            </Typography>
                        )}
                        {commit[type] && (
                            <Typography className={classes.title} type="subheading">
                                commit: {commit[type]}
                            </Typography>
                        )}
                    </div>
                </Grid>
            </Grid>
        );
    }

    renderSnapshot(type) {
        const { snapshot, disableDiffs, pixels, visibility, diffsVisibility, errorVisibility } = this.props;

        if (!snapshot.images[type]) {
            return null;
        }

        const {
            diffs,
            isActualShowed,
            actualNaturalImageWidth,
            actualNaturalImageHeight,
            isExpectedShowed,
            expectedNaturalImageWidth,
            expectedNaturalImageHeight
        } = this.state;

        const isDiffShown = type === 'actual' ? isActualShowed : isExpectedShowed;
        const handler = type === 'actual' ? this.handleActualImg : this.handleExpectedImg;
        const naturalWidth = type === 'actual' ? actualNaturalImageWidth : expectedNaturalImageWidth;
        const naturalHeight = type === 'actual' ? actualNaturalImageHeight : expectedNaturalImageHeight;

        return (
            <SnapshotItem
                snapshot={{
                    diffs: diffs[type],
                    pixels: snapshot.pixels
                }}
                disableDiffs={disableDiffs}
                isDiffShown={isDiffShown}
                showPixels={snapshot.pixels && pixels === type}
                naturalImageWidth={naturalWidth || 0}
                naturalImageHeight={naturalHeight || 0}
                imageSrc={snapshot.images[type]}
                onImageLoad={handler}
                visibility={visibility}
                diffsVisibility={diffsVisibility}
                errorVisibility={errorVisibility}
                isZoomEnabled={this.props.isZoomEnabled}
                zoomLevel={this.props.zoomLevel}
            />
        );
    }

    render() {
        const { classes, snapshot, visibility } = this.props;

        if (!snapshot) {
            return null;
        }

        const { images = {}, error } = snapshot;

        if (
            snapshot &&
            ((!images.actual && !images.expected) ||
                (error && [URLS_IMGS_NOT_FOUND, EMPTY_IMAGES, SNAPSHOTS_NOT_FOUND].includes(error.toLowerCase())))
        ) {
            return (
                <Grid container spacing={0}>
                    {error}
                </Grid>
            );
        }

        const showActual = !!images.actual;
        const showExpected = !!images.expected;
        const { isActualShowed, isExpectedShowed } = this.state;
        const stats = getSnapshotStats(snapshot);

        return (
            <Grid container spacing={0}>
                <Grid container spacing={0} className={classes.statsWrapper}>
                    <Grid item xs={12} className={classes.diffWrapper}>
                        {Object.keys(stats).map(
                            key =>
                                OMIT_STATS_KEY.indexOf(key) !== -1 ? null : (
                                    <SnapshotStatBlock
                                        key={key}
                                        title={key}
                                        value={stats[key]}
                                        isError={stats[key] > 0}
                                    />
                                )
                        )}
                    </Grid>
                    <Grid item xs={12} className={classes.diffWrapper}>
                        {stats.error && <SnapshotStatBlock title="error" value={stats.error} isError />}
                    </Grid>
                </Grid>

                {showActual && (
                    <Grid
                        item
                        xs={visibility === 'actual' ? 12 : 6}
                        className={cn({
                            [classes.diffsWrapper]: true,
                            [classes.hideDiff]: !isActualShowed
                        })}
                    >
                        {this.renderHeader('actual')}

                        <Dialog open={this.state.fullscreen.actual} onClose={this.handleFullscreenOff} fullWidth>
                            <Grid container spacing={0}>
                                <Grid item xs={12} className={classes.withOverflow}>
                                    {this.renderSnapshot('actual')}
                                </Grid>
                            </Grid>
                        </Dialog>

                        {this.renderSnapshot('actual')}
                    </Grid>
                )}

                {showExpected && (
                    <Grid
                        item
                        xs={visibility === 'expected' ? 12 : 6}
                        className={cn({
                            [classes.diffsWrapper]: true,
                            [classes.expectedWithoutActual]: !showActual,
                            [classes.hideDiff]: !isExpectedShowed
                        })}
                    >
                        {this.renderHeader('expected')}

                        <Dialog open={this.state.fullscreen.expected} onClose={this.handleFullscreenOff} fullWidth>
                            <Grid container spacing={0}>
                                <Grid item xs={12} className={classes.withOverflow}>
                                    {this.renderSnapshot('expected')}
                                </Grid>
                            </Grid>
                        </Dialog>

                        {this.renderSnapshot('expected')}
                    </Grid>
                )}
            </Grid>
        );
    }
}

SnapshotDiff.propTypes = {
    classes: pt.object.isRequired,
    snapshot: pt.object.isRequired,
    disableDiffs: pt.bool,
    pixels: pt.string,
    visibility: pt.oneOf(VISIBILITY),
    diffsVisibility: pt.arrayOf(pt.oneOf(DIFF_VISIBILITY_FILTERS)),
    errorVisibility: pt.arrayOf(pt.oneOf(DISPLAYED_DIFF_TYPES)),
    selectDiffItemByName: pt.func,
    selectedDiffItem: pt.string,
    isZoomEnabled: pt.bool,
    zoomLevel: pt.number
};

SnapshotDiff.defaultProps = {
    disableDiffs: false,
    pixels: '',
    visibility: 'all',
    selectedDiffItem: '',
    diffsVisibility: ['displayed'],
    errorVisibility: DISPLAYED_DIFF_TYPES,
    selectDiffItemByName: () => {},
    isZoomEnabled: false,
    zoomLevel: 1
};

export default withStyles(styles)(SnapshotDiff);
