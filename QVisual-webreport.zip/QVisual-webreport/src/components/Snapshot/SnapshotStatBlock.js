import React, { Component } from 'react';
import pt from 'prop-types';
import cn from 'classnames';
import { withStyles } from '@material-ui/core/styles';

const styles = () => ({
    title: {
        marginRight: '5px',
        textTransform: 'initial',
        color: '#9299A2'
    },
    value: {
        textTransform: 'initial',
        color: '#9299A2'
    },
    block: {
        display: 'flex',
        marginRight: '25px',
        fontSize: 12,
        fontWeight: 'normal'
    },
    error: {
        color: '#CD5C5C'
    }
});

class SnapshotStatBlock extends Component {
    render() {
        const { classes, isError, title, value } = this.props;

        return (
            <div className={classes.block}>
                <span className={classes.title}>{title}</span>
                <span
                    className={cn({
                        [classes.value]: true,
                        [classes.error]: isError
                    })}
                >
                    {value}
                </span>
            </div>
        );
    }
}

SnapshotStatBlock.propTypes = {
    classes: pt.object.isRequired,
    title: pt.string,
    value: pt.oneOfType([pt.string, pt.number]),
    isError: pt.bool
};

SnapshotStatBlock.defaultProps = {
    title: '',
    value: '',
    isError: false
};

export default withStyles(styles)(SnapshotStatBlock);
