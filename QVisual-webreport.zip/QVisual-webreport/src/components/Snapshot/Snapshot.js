import React, { Component } from 'react';
import pt from 'prop-types';
import { withStyles } from '@material-ui/core/styles';

// components
import SnapshotDiff from './SnapshotDiff';
import SnapshotAttrsBlock from './SnapshotAttrsBlock';
import ToolbarCtrls from '../Toolbar/ToolbarContainer';

// material components
import Grid from '@material-ui/core/Grid';
import Paper from '@material-ui/core/Paper';

const MARGIN = 15;
const SCROLLBAR_WIDTH = 17;

const styles = theme => ({
    root: {
        marginTop: '10px',
        paddingLeft: '10px',
        paddingRight: '10px'
    },
    fixedAttrBlock: {
        position: 'fixed',
        overflow: 'auto',
        backgroundColor: '#FFFFFF'
    },
    paperBar: {
        padding: 14
    },
    paper: {
        padding: '16px',
        textAlign: 'center',
        color: theme.palette.text.secondary
    },
    propDiff: {
        paddingLeft: '16px'
    }
});

class Snapshot extends Component {
    componentDidMount() {
        this.calcComponentDim();
    }

    calcComponentDim = () => {
        if (!this.attrBlock && this.props.snapshot && this.props.snapshot.error) {
            return;
        }

        const parent = this.attrBlock.parentNode;
        const wrapper = parent.parentNode.getBoundingClientRect();

        parent.style.width = `${wrapper.width - SCROLLBAR_WIDTH}px`;
        parent.style.height = `calc(100vh - ${wrapper.top + SCROLLBAR_WIDTH + MARGIN}px)`;
    };

    setRef = name => element => (this[name] = element);

    render() {
        const {
            classes,
            snapshot,
            pixels,
            storyTitle,
            stateTitle,
            disableDiffs,
            visibility,
            diffsVisibility,
            errorVisibility,
            selectDiffItemByName,
            selectedDiffItem,
            zoomEnabled,
            zoomLevel,
            match
        } = this.props;

        return (
            <Grid className={classes.root} container spacing={0}>
                <ToolbarCtrls match={match} enableZoomCtrl />

                <Grid item xs={9} className={classes.root}>
                    <SnapshotDiff
                        snapshot={snapshot}
                        disableDiffs={disableDiffs}
                        pixels={pixels}
                        visibility={visibility}
                        diffsVisibility={diffsVisibility}
                        errorVisibility={errorVisibility}
                        selectDiffItemByName={selectDiffItemByName}
                        selectedDiffItem={selectedDiffItem}
                        isZoomEnabled={zoomEnabled}
                        zoomLevel={zoomLevel}
                    />
                </Grid>

                <Grid item xs={3} className={classes.propDiff}>
                    <Paper className={classes.fixedAttrBlock}>
                        <div ref={this.setRef('attrBlock')}>
                            <SnapshotAttrsBlock
                                snapshot={snapshot}
                                selectDiffItemByName={selectDiffItemByName}
                                selectedDiffItem={selectedDiffItem}
                                parentRef={this.attrBlock && this.attrBlock.parentNode}
                                diffsVisibility={diffsVisibility}
                                errorVisibility={errorVisibility}
                            />
                        </div>
                    </Paper>
                </Grid>
            </Grid>
        );
    }
}

Snapshot.propTypes = {
    classes: pt.object.isRequired,
    snapshot: pt.object.isRequired,
    storyTitle: pt.string.isRequired,
    stateTitle: pt.string.isRequired,
    selectedDiffItem: pt.string,
    disableDiffs: pt.bool,
    pixels: pt.string,
    visibility: pt.string,
    diffsVisibility: pt.array,
    errorVisibility: pt.array,
    selectDiffItemByName: pt.func,
    zoomLevel: pt.number,
    zoomEnabled: pt.bool
};

export default withStyles(styles)(Snapshot);
