import * as React from 'react';
import { Route, Switch } from 'react-router-dom';
import { withStyles } from '@material-ui/core/styles';
import Main from '../MainPage/Main';
import Snapshot from '../Snapshot/SnapshotContainer';

const styles = theme => ({
    withToolbar: {
        paddingTop: `${theme.mixins.toolbar.minHeight * 2.5}px`
    }
});

class App extends React.Component<any> {
    render() {
        return (
            <div>
                <main className={this.props.classes.withToolbar}>
                    <Switch>
                        <Route exact path="/" component={Main} />
                        <Route exact path="/actual/:actual/expected/:expected/story" component={Snapshot} />
                        <Route exact path="/actual/:actual/expected/:expected/:reload" component={Main} />
                        <Route exact path="/actual/:actual/expected/:expected" component={Main} />
                        <Route exact path="/story" component={Snapshot} />
                    </Switch>
                </main>
            </div>
        );
    }
}

export default withStyles(styles)(App);
