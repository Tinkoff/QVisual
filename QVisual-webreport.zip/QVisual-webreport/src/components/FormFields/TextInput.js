import React from 'react';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import Input from '@material-ui/core/Input';

const styles = theme => ({
    textField: {
        marginRight: theme.spacing.unit,
        width: 200
    }
});

function TextInput(props) {
    const { classes, placeholder, id, name } = props;

    return <Input id={id} name={name} placeholder={placeholder} className={classes.textField} />;
}

TextInput.propTypes = {
    classes: PropTypes.object.isRequired
};

export default withStyles(styles)(TextInput);
