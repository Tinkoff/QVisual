import React, { Component } from 'react';
import pt from 'prop-types';
import Table from './DiffTable';

class AttrDiffTableContainer extends Component {
    state = {
        items: []
    };

    componentWillMount() {
        const { element, attributeName } = this.props;

        if (!element || !attributeName) {
            return;
        }

        const items = [];
        const attrs = element[attributeName];
        const attrKeys = Object.keys(attrs);

        if (!attrKeys.length) {
            return;
        }

        attrKeys.forEach(item => {
            const rowItem = {
                attr: item,
                actual: attrs[item].actual,
                expected: attrs[item].expected
            };

            if (attrs[item].diff) {
                rowItem.diff = attrs[item].diff;
            }

            items.push(rowItem);
        });

        this.setState({ items });
    }

    render() {
        const { columns } = this.props;
        const { items } = this.state;

        if (!items.length) {
            return null;
        }

        return <Table columns={columns} body={items} />;
    }
}

AttrDiffTableContainer.propTypes = {
    columns: pt.array.isRequired,
    attributeName: pt.string.isRequired,
    element: pt.object
};

export default AttrDiffTableContainer;
