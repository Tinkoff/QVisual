import React, { Component } from 'react';
import pt from 'prop-types';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';

class DiffTable extends Component {
    renderTableHead = () => {
        return this.props.columns.map(column => {
            return (
                <TableCell key={column.id} numeric={column.numeric}>
                    {column.label}
                </TableCell>
            );
        }, this);
    };

    renderTableBody() {
        const { body, columns } = this.props;
        const columnKeys = columns.map(col => col.id);

        return body.map((item, key) => {
            const cells = columnKeys.map((col, idx) => {
                return (
                    <TableCell key={`bodycell-${idx}`} title={item.diff || ''}>
                        {item[col]}
                    </TableCell>
                );
            });

            return <TableRow key={key}>{cells}</TableRow>;
        });
    }

    render() {
        const { body } = this.props;

        if (!body.length) {
            return null;
        }

        return (
            <Table>
                <TableHead>
                    <TableRow>{this.renderTableHead()}</TableRow>
                </TableHead>
                <TableBody>{this.renderTableBody()}</TableBody>
            </Table>
        );
    }
}

DiffTable.propTypes = {
    columns: pt.array,
    body: pt.array
};

DiffTable.defaultProps = {
    columns: [],
    body: []
};

export default DiffTable;
