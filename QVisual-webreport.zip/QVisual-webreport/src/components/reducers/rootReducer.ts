import { combineReducers } from 'redux';
import { routerReducer } from 'react-router-redux';
import {
    SNAPSHOT_ZOOM,
    SNAPSHOT_ZOOM_ENABLE,
} from './actionTypes';
import { storyReducer, filterStateChanged } from './storyReducer';
import { board } from './boardReducer';
import { storiesFilter } from './storiesFilter';
import * as FilterActions from './filterActionTypes';
import { ApplicationState } from '../../types';


// snapshot state
const defaultSnapshotState = {
    zoomEnabled: false,
    zoom: 1
};

export const setZoomState = value => ({ type: SNAPSHOT_ZOOM_ENABLE, value });
export const setZoomLevel = value => ({ type: SNAPSHOT_ZOOM, value });

export const snapshot = (state = defaultSnapshotState, action) => {
    switch (action.type) {
        case SNAPSHOT_ZOOM_ENABLE:
            return {
                zoomEnabled: action.value,
                zoom: 1
            };
        case SNAPSHOT_ZOOM:
            return {
                ...state,
                zoom: action.value
            };
        default:
            return state;
    }
};

const filterActions = Object.values(FilterActions);
function crossStoriesReducer(state: ApplicationState, action) {
    if (filterActions.includes(action.type)) {
        return {
            ...state,
            stories: storyReducer(state.stories, filterStateChanged(state.storiesFilter)),
        } as Partial<ApplicationState>
    }
    return state;
}

const combinedReducers = combineReducers<ApplicationState>({
    routing: routerReducer,
    stories: storyReducer,
    storiesFilter,
    snapshot,
    board,
});

export default function rootReducer(state, action) {
    const intermediateState = combinedReducers(state, action);
    const finalState = crossStoriesReducer(intermediateState, action);
    return finalState;
}