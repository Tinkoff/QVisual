import { FetchedStory, Snapshot, StoriesFilterState, State, Story } from "../../types";
import { RESOLUTIONS, BROWSERS, ENVIRONMENTS, SKIP_FILTER } from '../FilterByEnv/constants/filters';
import { DISPLAY_TO_KEY } from "../Snapshot/constants/filters";

export const makeId = (...args: number[]) => args.join('-');
export const alphabeticSortBy = <T>(prop: keyof T) => (a: Record<keyof T, string>, b: Record<keyof T, string>) => a[prop].localeCompare(b[prop]);
export const byName = alphabeticSortBy('name');

const inRange = (value: number) => (range: [number, number]) => {
  const min = Math.min(...range);
  const max = Math.max(...range);
  return min <= value && value <= max;
}
export const hasError = ({ elements, pixels, error }: Snapshot) => elements.length || pixels || error;

const isDiffVisibilitySnapshot = ({ elements }: Snapshot, { diffsVisibility, errorVisibility }: StoriesFilterState) => {
  return elements
    .filter(e => e)
    .some(element => {
      const hasDisplayType = diffsVisibility.indexOf(DISPLAY_TO_KEY[element.display]) > -1;

      if (hasDisplayType && element.display !== 'displayed') {
        return true;
      }

      // только у типа 'displayed' могут быть ошибки из errorVisibility
      const hasErrorType = element.diff.some(type => errorVisibility.indexOf(type) > -1);

      return hasErrorType && hasDisplayType;
    });
}


export const filterSnapshots = (snapshots: Snapshot[], filterStories: StoriesFilterState) => {
  const { environment, browser, resolutions, showWithErrors, pixelRanges, showWithElements, showNoAnyError } = filterStories;

  const showWithPixelRange = pixelRanges.length !== 0;
  const isAnyFilterSelected = showWithErrors || showWithElements || showWithPixelRange;

  const envs = environment.length ? environment : ENVIRONMENTS;
  const browsers = browser.length ? browser : BROWSERS;
  const res = resolutions.length ? resolutions : RESOLUTIONS;

  const filteredSnapshots = [] as Snapshot[];

  for (let snapshot of snapshots) {
    const hasElements = snapshot.elements && snapshot.elements.length;
    const hasError = !!snapshot.error;
    const hasPixels = !!snapshot.diffPercentage;

    if ((hasPixels || hasError || hasElements) && showNoAnyError)
      continue;

    const os = snapshot.browser.osName.toLowerCase();
    const browserAttr = snapshot.browser.browserName;
    const browserName = browserAttr.toLowerCase();
    const width = snapshot.browser.resolution.split('x')[0];

    const isRelevantByEnvironment = (
      envs.some(value => value === SKIP_FILTER || value === os) &&
      browsers.some(value => value === SKIP_FILTER || value === browserName) &&
      res.some(value => value === SKIP_FILTER || value === width)
    );

    const isRelevantByVisibility = (hasElements &&
      isDiffVisibilitySnapshot(snapshot, filterStories)
    );

    const inPixelsRange = inRange(snapshot.diffPercentage || -1);

    const filtersRelevant = [
      showWithPixelRange && pixelRanges.some(inPixelsRange),
      showWithElements && isRelevantByVisibility,
      showWithErrors && hasError
    ];

    const isRelevantByFilters = !isAnyFilterSelected || filtersRelevant.some(e => e);

    const isRelevant = isRelevantByEnvironment && isRelevantByFilters;

    if (!isRelevant)
      continue;

    filteredSnapshots.push(snapshot);
  }
  return filteredSnapshots;
};

export const patchStories = (stories: FetchedStory[]): Story[] => {
  const patched = [] as Story[];

  stories.forEach(({ states, story }, storyIndex) => {
    let storyFailed = false;
    const patchedStates = [] as State[];

    states.forEach(({ state, snapshots }, stateIndex) => {
      let stateFailed = false;
      let snapshotTestCaseId = null;
      snapshots.forEach((snapshot, snapshotIndex) => {
        const failed = Boolean(snapshot.elements.length || !!snapshot.error || snapshot.diffPercentage);
        storyFailed = storyFailed || failed;
        stateFailed = stateFailed || failed;
        snapshotTestCaseId = snapshotTestCaseId || snapshot.testcaseId;

        if (!snapshot.elements)
          snapshot.elements = [];

        snapshot.failed = failed;
        snapshot.id = makeId(storyIndex, stateIndex, snapshotIndex);
      });

      patchedStates.push({
        name: state,
        failed: stateFailed,
        snapshotTestCaseId: snapshotTestCaseId,
        snapshots: snapshots,
        id: makeId(storyIndex, stateIndex)
      });
    });

    patched.push({
      name: story,
      failed: storyFailed,
      states: patchedStates,
      id: makeId(storyIndex)
    });
  });

  return patched;
}




export function isEmpty(object: Object) {
  for (let prop in object) {
    if (object.hasOwnProperty(prop))
      return false;
  }
  return true;
}