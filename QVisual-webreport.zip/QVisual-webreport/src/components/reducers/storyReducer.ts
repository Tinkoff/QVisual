import {
  FETCH_STORIES, SELECT_STATE, SELECT_STORY, MOVE_CURRENT_STORY_IDX, MOVE_CURRENT_STATE_IDX, SELECT_TAB, SELECT_SNAPSHOT, FILTER_STATE_CHANGED
} from './actionTypes';
import { StoriesState, FetchedStory, Story, StoriesFilterState, State } from '../../types';
import { filterSnapshots, byName, patchStories } from './utils';
import { byPriorities, findCurrents } from '../../utils/snapshot';
import { defaultVisibilityFilters } from './storiesFilter';

const defaultStories: StoriesState = {
  filteredStories: [],
  stories: [],
  currentStoryIndex: -1,
  currentStateIndex: -1,
  currentSnapshotIndex: -1,
};

export const selectStory = (id: string) => ({ type: SELECT_STORY, value: id });
export const selectState = (id: string) => ({ type: SELECT_STATE, value: id });
export const selectSnapshot = (id: string) => ({ type: SELECT_SNAPSHOT, value: id });
export const selectTab = (id: string) => ({ type: SELECT_TAB, value: id });
export const moveCurrentStoryIdx = (value: number) => ({ type: MOVE_CURRENT_STORY_IDX, value });
export const moveCurrentStateIdx = (value: number) => ({ type: MOVE_CURRENT_STATE_IDX, value });
export const filterStateChanged = (value: StoriesFilterState) => ({ type: FILTER_STATE_CHANGED, value })

// story data
export const fetchStories = (stories: FetchedStory[], snapshotParams?) => {
  const patched = patchStories(stories);
  let result = patched;

  if (snapshotParams) {
    const { state, story, snapshot } = findCurrents(patched, snapshotParams);
    result = [{
      ...story,
      states: [{
        ...state,
        snapshots: [snapshot]
      }]
    }]
  }

  return ({
    type: FETCH_STORIES,
    value: result,
    isSnapshotPage: snapshotParams,
  })
};

const filterStories = (stories: Story[], storiesFilterState: StoriesFilterState) => {
  const filteredStories = [] as Story[];

  for (let story of stories) {
    const filteredStates = [] as State[];

    for (let state of story.states) {
      const snapshots = filterSnapshots(state.snapshots, storiesFilterState);
      if (snapshots.length === 0)
        continue;

      filteredStates.push({
        ...state,
        snapshots: snapshots.sort(byPriorities),
      });
    }

    if (filteredStates.length === 0)
      continue;

    const orderedStates = filteredStates.sort(byName);
    filteredStories.push({
      ...story,
      states: orderedStates,
    })
  }

  return filteredStories.sort(byName);
};


export const storyReducer = (state = defaultStories, action): StoriesState => {
  const { filteredStories, currentStateIndex, currentStoryIndex, stories } = state;

  switch (action.type) {
    case FETCH_STORIES: {
      const patched: Story[] = action.value || [];
      const filteredStories = action.isSnapshotPage
        ? patched
        : filterStories(patched, defaultVisibilityFilters);

      return {
        stories: patched,
        filteredStories,
        currentStoryIndex: 0,
        currentStateIndex: 0,
        currentSnapshotIndex: 0,
      };
    }
    case SELECT_STORY:
      const storyIndex = filteredStories.findIndex(e => e.id === action.value);
      return {
        ...state,
        currentStoryIndex: storyIndex,
        currentStateIndex: 0,
        currentSnapshotIndex: 0,
      }
    case SELECT_STATE:
      const stateIndex = filteredStories[currentStoryIndex]
        .states
        .findIndex(e => e.id === action.value);
      return {
        ...state,
        currentStateIndex: stateIndex,
        currentSnapshotIndex: 0,
      }
    case SELECT_SNAPSHOT:
      const snapshotIndex = filteredStories[currentStoryIndex]
        .states[currentStateIndex]
        .snapshots
        .findIndex(e => e.id === action.value);
      return {
        ...state,
        currentSnapshotIndex: snapshotIndex,
      }
    case MOVE_CURRENT_STORY_IDX:
      return {
        ...state,
        currentStoryIndex: state.currentStoryIndex + action.value,
        currentStateIndex: 0,
        currentSnapshotIndex: 0,
      }
    case MOVE_CURRENT_STATE_IDX:
      return {
        ...state,
        currentStateIndex: state.currentStateIndex + action.value,
        currentSnapshotIndex: 0,
      }
    case SELECT_TAB:
      return {
        ...state,
        currentSnapshotIndex: action.value,
      }

    case FILTER_STATE_CHANGED:
      const newStories = filterStories(stories, action.value);
      return {
        ...state,
        ...getNewIndexes(state, newStories),
        filteredStories: newStories
      };
    default:
      return state;
  }
};

const getNewIndexes = ({ currentStoryIndex, currentSnapshotIndex, currentStateIndex, filteredStories: stories }: StoriesState, filteredStories: Story[]) => {
  const result = {
    currentStoryIndex: 0,
    currentStateIndex: 0,
    currentSnapshotIndex: 0,
  };

  const previousStory = stories[currentStoryIndex];
  if (!previousStory)
    return result;

  const newStoryIndex = filteredStories.findIndex(st => st.name === previousStory.name);
  if (newStoryIndex === -1)
    return result;
  else
    result.currentStoryIndex = newStoryIndex;

  const previousState = previousStory.states[currentStateIndex];
  if (!previousState)
    return result;

  const newStateIndex = filteredStories[newStoryIndex].states.findIndex(st => st.name === previousState.name);
  if (newStateIndex === -1)
    return result;
  else
    result.currentStateIndex = newStateIndex;

  const previousSnapshot = previousState.snapshots[currentSnapshotIndex];
  if (!previousSnapshot)
    return result;

  const newSnapshotIndex = filteredStories[newStoryIndex].states[newStateIndex].snapshots.findIndex(st => st.id === previousSnapshot.id);
  if (newSnapshotIndex === -1)
    return result;
  else
    result.currentSnapshotIndex = newSnapshotIndex;

  return result;
}