import {
  FILTER_DISABLE_DIFF,
  FILTER_SHOW_PIXELS,
  FILTER_SNAPSHOT_VISIBILITY,
  FILTER_SNAPSHOT_DIFF_VISIBILITY,
  FILTER_SNAPSHOT_ERROR_VISIBILITY,
  FILTER_ENV_ENVIRONMENT,
  FILTER_ENV_BROWSER,
  FILTER_ENV_RESOLUTION,
  FILTER_SELECTED_DIFF,
  FILTER_SHOW_WITH_ERROR,
  FILTER_SHOW_WITH_ELEMENTS,
  FILTER_SHOW_RANGE_CHANGED,
  FILTER_SHOW_WITH_NO_ANY_ERRORS
} from './filterActionTypes';

import { SKIP_FILTER } from '../FilterByEnv/constants/filters';
import { StoriesFilterState, StatsFilterKeys } from '../../types';

const defaultStatsFilters = {
  pixelRanges: [],
  showWithErrors: false,
  showWithElements: false,
} as StatsFilterKeys;

export const defaultVisibilityFilters = {
  disableDiffs: true,
  pixels: 'actual',
  visibility: 'all',
  diffsVisibility: ['displayed'],
  errorVisibility: ['image', 'moved', 'text', 'resized'],
  environment: [SKIP_FILTER],
  browser: [SKIP_FILTER],
  resolutions: [SKIP_FILTER],
  selectedDiff: '',
  ...defaultStatsFilters,
} as StoriesFilterState;

export const setDisableDiffFilter = value => ({ type: FILTER_DISABLE_DIFF, value });
export const setPixelsFilter = value => ({ type: FILTER_SHOW_PIXELS, value });
export const setSnapshotFilter = value => ({ type: FILTER_SNAPSHOT_VISIBILITY, value });
export const setDiffFilter = value => ({ type: FILTER_SNAPSHOT_DIFF_VISIBILITY, value });
export const setErrorFilter = value => ({ type: FILTER_SNAPSHOT_ERROR_VISIBILITY, value });
export const setEnvFilter = value => ({ type: FILTER_ENV_ENVIRONMENT, value });
export const setBrowserFilter = value => ({ type: FILTER_ENV_BROWSER, value });
export const setResolutionFilter = value => ({ type: FILTER_ENV_RESOLUTION, value });
export const selectDiffItemByName = value => ({ type: FILTER_SELECTED_DIFF, value });

export const setShowWithErrorFilter = value => ({ type: FILTER_SHOW_WITH_ERROR, value });
export const setShowWithElementsFilter = value => ({ type: FILTER_SHOW_WITH_ELEMENTS, value });
export const changePixelRangeFilter = value => ({ type: FILTER_SHOW_RANGE_CHANGED, value });
export const changeShowWithNoAnyErrors = value => ({ type: FILTER_SHOW_WITH_NO_ANY_ERRORS, value });

export const storiesFilter = (state = defaultVisibilityFilters, action): StoriesFilterState => {
  switch (action.type) {
    case FILTER_DISABLE_DIFF:
      // отображаем\не отображаем diff'ы
      return {
        ...state,
        disableDiffs: action.value
      };
    case FILTER_SHOW_PIXELS:
      // отображаем попиксельную разницу для actual/expected картинки и свойства pixels
      return {
        ...state,
        pixels: state.pixels === action.value ? '' : action.value
      };
    case FILTER_SNAPSHOT_VISIBILITY:
      // показываем либо ожидаемую картинку (свойство actual),
      // либо expected картинку, либо все
      return {
        ...state,
        visibility: action.value
      };
    case FILTER_SNAPSHOT_DIFF_VISIBILITY:
      // фильтруем по свойству display
      return {
        ...state,
        diffsVisibility: action.value
      };
    case FILTER_SNAPSHOT_ERROR_VISIBILITY:
      // фильтруем по свойству diff, который не пустой только у display === 'displayed'
      return {
        ...state,
        errorVisibility: action.value
      };
    case FILTER_ENV_ENVIRONMENT:
      // фильтруем по browser.osName
      return {
        ...state,
        environment: action.value
      };
    case FILTER_ENV_BROWSER:
      // фильтруем по browser.browserName
      // со стороны апи может быть выставлено только одно из этих свойств
      return {
        ...state,
        browser: action.value
      };
    case FILTER_ENV_RESOLUTION:
      // фильтруем по browser.resolution, по тому что стоит слева от знака 'x', т.е. по ширине
      return {
        ...state,
        resolutions: action.value
      };
    case FILTER_SELECTED_DIFF:
      // указываем какой diff следует выделить при клике, а также в таблице на детальном отчете
      return {
        ...state,
        selectedDiff: action.value
      };
    case FILTER_SHOW_WITH_ERROR:
      // указываем какой diff следует выделить при клике, а также в таблице на детальном отчете
      return {
        ...state,
        showWithErrors: action.value
      };
    case FILTER_SHOW_WITH_ELEMENTS:
      // указываем какой diff следует выделить при клике, а также в таблице на детальном отчете
      return {
        ...state,
        showWithElements: action.value
      };
    case FILTER_SHOW_RANGE_CHANGED:
      // указываем какой diff следует выделить при клике, а также в таблице на детальном отчете
      return {
        ...state,
        pixelRanges: action.value
      };
    case FILTER_SHOW_WITH_NO_ANY_ERRORS:
      return {
        ...state,
        ...(action.value ? defaultStatsFilters : {}),
        showNoAnyError: action.value
      }
    default:
      return state;
  }
};