import { SWITCH_SHOW_BOARD } from "./actionTypes";

// board

export const switchBoard = () => ({ type: SWITCH_SHOW_BOARD });

const defaultBoardState = {
  showSnapshot: false
};

export const board = (state = defaultBoardState, action) => {
  switch (action.type) {
    case SWITCH_SHOW_BOARD:
      return {
        ...state,
        showSnapshot: !state.showSnapshot
      };
    default:
      return state;
  }
};

export const onStoreInitialized = (store) => {
  document.addEventListener('keydown', event => {
    const { key, keyCode } = event;
    if (
      key === 'Escape' || key === "Esc" || keyCode === 27
    )
      store.dispatch(switchBoard());
  });
}