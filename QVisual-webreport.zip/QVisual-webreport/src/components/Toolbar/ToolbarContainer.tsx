import * as React from 'react';
import { withRouter } from 'react-router';
import { compose } from 'redux';
import { connect } from 'react-redux';

// action creators
import {
    setDisableDiffFilter,
    setPixelsFilter,
    setSnapshotFilter,
    setDiffFilter,
    setErrorFilter
} from '../reducers/storiesFilter';

import { setZoomLevel, setZoomState } from '../reducers/rootReducer';
// components
import Toolbar from './Toolbar';

// utils
import request from '../../utils/request';
import queryString from '../../utils/queryString';
import updateFilterState from '../../utils/pureArrayUpdate';
import { fetchStories } from '../reducers/storyReducer';

type LoadingState = {
    open: boolean,
    message: string,
    disabled?: boolean,
    reloading?: boolean,
}

class ToolbarContainer extends React.Component<Props & DispatchFunc, any> {
    state = {
        open: false,
        message: '',
        disabled: false,
        reloading: false,
        anchorEl: null
    };

    LOADING_STATE: LoadingState;
    RELOADING_STATE: LoadingState;
    LOADED_STATE: LoadingState;

    constructor(props) {
        super(props);
        this.LOADING_STATE = { open: true, message: 'Loading stories...', disabled: true };
        this.RELOADING_STATE = { open: true, message: 'Reloading snapshot...', disabled: true, reloading: true };
        this.LOADED_STATE = { open: false, message: '', disabled: false, reloading: false };
    }
    async componentDidMount() {
        const { fetchParams, isLoad, enableZoomCtrl } = this.props;

        if (enableZoomCtrl) {
            this.props.setZoomState(true);
        }

        if (!fetchParams.actual || !fetchParams.expected || isLoad) {
            return;
        }

        this.setState(this.LOADING_STATE);
        this.loadStories(fetchParams).then(() => this.setState(this.LOADED_STATE));
    }

    componentWillUnmount() {
        if (this.props.enableZoomCtrl) {
            this.props.setZoomState(false);
        }
    }

    loadStories = async params => {
        try {
            const result = await request('/snapshots/report', params);
            const isSnapshotPage = this.props.match.url.includes('story');

            this.props.updateStories(result.stories, isSnapshotPage && params);
        } catch (err) {
            this.setState({ open: true, message: err.toString(), disabled: false });
        }
    };

    reloadSnapshot = () => {
        const { fetchParams } = this.props;
        if (!fetchParams.actual || !fetchParams.expected) {
            return;
        }
        this.setState(this.RELOADING_STATE);
        this.loadStories({ ...fetchParams, reload: true }).then(() => this.setState(this.LOADED_STATE));
    };

    handleRequest = async event => {
        event.preventDefault();
    };

    handleErrorClose = () => {
        this.setState({ open: false });
    };

    handleZoomLevel = level => () => {
        if (this.props.zoomLevel === level) {
            return this.props.setZoomLevel(1);
        }

        this.props.setZoomLevel(level);
    };

    handleDiffShow = () => {
        this.props.setDisableDiffFilter(!this.props.disableDiffs);
    };

    handlePixelsShow = event => {
        const { dataset } = event.currentTarget;

        if (!dataset.type) {
            return null;
        }

        this.props.setPixelsFilter(dataset.type);
    };

    handleVisibility = visibility => () => {
        this.props.setSnapshotFilter(visibility);
    };

    handleDiffsVisibility = visibility => () => {
        const filterState = this.props.diffsVisibility;
        const filters = updateFilterState(filterState, visibility);

        this.props.setDiffFilter(filters);
    };

    handleErrorVisibility = visibility => () => {
        const filterState = this.props.errorVisibility;
        const filters = updateFilterState(filterState, visibility);

        this.props.setErrorFilter(filters);
    };

    handleOpenMenu = event => {
        this.setState({ anchorEl: event.currentTarget });
    };

    handleCloseMenu = event => {
        const { target, currentTarget } = event;

        if (target === currentTarget) {
            this.setState({ anchorEl: null });
        }
    };

    render() {
        return (
            <Toolbar
                handleOpenMenu={this.handleOpenMenu}
                handleCloseMenu={this.handleCloseMenu}
                handleRequest={this.handleRequest}
                handleErrorClose={this.handleErrorClose}
                handleZoomLevel={this.handleZoomLevel}
                handleDiffShow={this.handleDiffShow}
                handlePixelsShow={this.handlePixelsShow}
                handleVisibility={this.handleVisibility}
                handleDiffsVisibility={this.handleDiffsVisibility}
                handleErrorVisibility={this.handleErrorVisibility}
                reloadSnapshot={this.reloadSnapshot}
                disableDiffs={this.props.disableDiffs}
                pixels={this.props.pixels}
                visibility={this.props.visibility}
                diffsVisibility={this.props.diffsVisibility}
                errorVisibility={this.props.errorVisibility}
                zoomLevel={this.props.zoomLevel}
                enableShowErrorFilter={this.props.enableShowErrorFilter}
                enableEnvFilter={this.props.enableEnvFilter}
                enableZoomCtrl={this.props.enableZoomCtrl}
                enableReload={this.props.enableReload}
                open={this.state.open}
                anchorEl={this.state.anchorEl}
                message={this.state.message}
                disabled={this.state.disabled}
                reloading={this.state.reloading}
                match={this.props.match}
            />
        );
    }
}

interface Props {
    match: {
        url: string,
    },
    location: object,
    isLoad: boolean,
    enableRequestForm: boolean,
    fetchParams: {
        actual: string,
        expected: string,
        reload: boolean,
    }
    // show\hide pixels diff
    setPixelsFilter: (...args) => any,
    pixels: string,
    // show\hide diffs
    disableDiffs: boolean,
    setDisableDiffFilter: (...args) => any,
    // filter for visibility of diffs
    visibility: string,
    setSnapshotFilter: (...args) => any,
    // filter for display attribute
    diffsVisibility: any[],
    setDiffFilter: (...args) => any,
    // filter for diff attribute
    errorVisibility: any[],
    setErrorFilter: (...args) => any,
    // filter for browser attribute
    enableEnvFilter: boolean,
    // snapshots has errors
    enableShowErrorFilter: boolean,
    // zoom
    enableZoomCtrl: boolean,
    zoomLevel: number,
    zoomEnabled: boolean,
    setZoomState: (...args) => any,
    setZoomLevel: (...args) => any,
    // reloading
    enableReload: boolean
};

(ToolbarContainer as any).defaultProps = {
    enableRequestForm: false,
    enableEnvFilter: false,
    enableShowErrorFilter: false,
    enableZoomCtrl: false,
    enableReload: false
};

const mapStateToProps = ({ stories: { stories }, storiesFilter, snapshot }, { match }) => {
    const { actual, expected, reload } = match.params;
    const queryParams = queryString(location.search);
    const fetchParams = {
        actual,
        expected,
        ...queryParams,
        reload: reload === 'reload'
    };

    return {
        fetchParams,
        disableDiffs: storiesFilter.disableDiffs,
        pixels: storiesFilter.pixels,
        showWithError: storiesFilter.showWithError,
        visibility: storiesFilter.visibility,
        diffsVisibility: storiesFilter.diffsVisibility,
        errorVisibility: storiesFilter.errorVisibility,
        isLoad: Boolean(stories[0] || stories[1] || stories[2]),
        zoomLevel: snapshot.zoom,
        zoomEnabled: snapshot.zoomEnabled,
        match
    };
};

const mapDispatchToProps = {
    updateStories: fetchStories,
    setDisableDiffFilter,
    setSnapshotFilter,
    setDiffFilter,
    setPixelsFilter,
    setErrorFilter,
    setZoomLevel,
    setZoomState,
} as DispatchFunc;

interface DispatchFunc {
    updateStories: typeof fetchStories,
    setDisableDiffFilter: typeof setDisableDiffFilter,
    setSnapshotFilter: typeof setSnapshotFilter,
    setDiffFilter: typeof setDiffFilter,
    setPixelsFilter: typeof setPixelsFilter,
    setErrorFilter: typeof setErrorFilter,
    setZoomLevel: typeof setZoomLevel,
    setZoomState: typeof setZoomState,
}

export default compose(withRouter, connect(mapStateToProps, mapDispatchToProps))(ToolbarContainer);
