import * as React from "react"
import { withStyles, StyleRules } from '@material-ui/core/styles';
import Tooltip from '@material-ui/core/Tooltip';
import Button from '@material-ui/core/Button';
import FilterList from '@material-ui/icons/FilterList';
import Menu from '@material-ui/core/Menu';
import MenuItem from '@material-ui/core/MenuItem';
import Checkbox from '@material-ui/core/Checkbox';
import { setShowWithElementsFilter, setShowWithErrorFilter, changePixelRangeFilter, changeShowWithNoAnyErrors } from "src/components/reducers/storiesFilter";
import { StatsFilterKeys, ApplicationState } from "../../../types";
import { connect } from 'react-redux';
import { compose } from 'redux';
import { getRanges, pixelRangePrefix } from "./utils";

const cn = require('classnames');

const showWithFilters: (keyof StatsFilterKeys)[] = [
  'showWithErrors',
  'showWithElements'
];

const ranges = [1, 10, 50, 100];
const rangesTitle = getRanges(ranges);
const statsFilters = rangesTitle.concat(
  showWithFilters,
);

type DispatchFunctions = typeof mapDispatchToProps;

interface MappedStateProps {
  showWithErrors: boolean,
  showWithElements: boolean,
  showNoAnyError: boolean,
}
interface OwnProps {
  customClasses: any;
  disabled?: boolean;
  classes?: any;
}

interface State {
  anchorEl: any;
  pixelRangeChecked: {
    [key: string]: boolean
  }
}

const styles = theme => ({
  root: {
    color: '#EEF2F7',
    '&$checked': {
      color: '#75A3C6',
    },
  },
  checked: {},
  showErrorFilterMenuContainer: {
    position: 'absolute',
    bottom: '-30px',
  },
  filterMenu: {
    maxHeight: '100%',
  },
  filterMenuItem: {
    color: '#EEF2F7',
    padding: '7px 20px 6px 4px',
    fontSize: 14
  }
} as StyleRules);


class FilterByErrorsButton extends React.Component<DispatchFunctions & MappedStateProps & OwnProps, State> {
  state = {
    anchorEl: null,
    pixelRangeChecked: rangesTitle
      .filter(key => key.startsWith(pixelRangePrefix))
      .reduce((a, b) => ({ ...a, [b]: false }), {})
  }
  anchorRef = React.createRef();

  render() {
    const { customClasses, classes, disabled, showNoAnyError } = this.props;
    const { anchorEl, pixelRangeChecked } = this.state;
    const isOpen = anchorEl !== null;
    return <div>
      <Tooltip
        title="Скрыть скриншоты без ошибок"
        placement="bottom-start"
        classes={{ tooltip: customClasses.darkTooltip }}
      >
        <Button
          className={customClasses.buttonCtrl}
          onClick={this.toggleMenu}
          disabled={disabled}
          size="small"
          disableRipple
        >
          <FilterList
            className={cn({
              [customClasses.notActive]: !isOpen
            })}
          />
        </Button>
      </Tooltip>
      <Menu
        id="simple-menu"
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={this.toggleMenu}
        className={classes.filterMenu}
      >
        {
          statsFilters.map((key, i) => {
            const isChecked = !!(pixelRangeChecked[key] || this.props[key]);
            if (i === 0)
              console.log(isChecked);
            return (
              <MenuItem
                key={i}
                className={classes.filterMenuItem}
                onClick={this.onCheckboxClicked(key)}
              >
                <Checkbox
                  checked={isChecked}
                  disabled={showNoAnyError}
                  classes={{
                    root: classes.root,
                    checked: classes.checked,
                  }}
                />
                {
                  this.filterKeyTitleMap[key] || key
                }
              </MenuItem>
            )
          }
          )
        }
        <MenuItem
          className={classes.filterMenuItem}
          onClick={this.onNoAnyClicked}
        >
          <Checkbox
            checked={showNoAnyError}
            classes={{
              root: classes.root,
              checked: classes.checked,
            }}
          />
          Success tests
        </MenuItem>
      </Menu>
      <div ref={this.anchorRef as any} className={classes.showErrorFilterMenuContainer}></div>
    </div>
  }

  filterKeyTitleMap = {
    'showWithErrors': 'Errors',
    'showWithElements': 'Elements'
  } as Record<keyof StatsFilterKeys, string>;

  onNoAnyClicked = e => {
    e.preventDefault();
    const current = !this.props.showNoAnyError;
    if (current) {
      this.setState({
        pixelRangeChecked: {}
      });
    }

    this.props.changeShowWithNoAnyErrors(
      current
    );
  }

  onCheckboxClicked = (key: string) => (e) => {
    e.preventDefault();

    if (this.props.showNoAnyError)
      return;

    const { showWithElements, showWithErrors, setShowWithElementsFilter, showNoAnyError, setShowWithErrorFilter, changeShowWithNoAnyErrors } = this.props;
    switch (key) {
      case 'showWithErrors':
        setShowWithErrorFilter(!showWithErrors);
        break;
      case 'showWithElements':
        setShowWithElementsFilter(!showWithElements);
        break;
      default:
        this.changePixelRange(key)
    }
  }

  changePixelRange = (key: string) => {
    const { pixelRangeChecked } = this.state;
    const ranges = {
      ...pixelRangeChecked,
      [key]: !pixelRangeChecked[key]
    };

    const extractRange = (str: string) => str.match(/\d+/g) || [];
    const rangeValues = Object.keys(ranges)
      .filter(key => ranges[key])
      .map(extractRange);

    this.setState({
      pixelRangeChecked: ranges
    });

    this.props.changePixelRangeFilter(rangeValues);
  }

  toggleMenu = () => {
    this.setState(prevState => ({
      anchorEl: prevState.anchorEl ? null : this.anchorRef.current,
    }))
  }
}

const mapStateToProps = ({ storiesFilter: { showWithElements, showWithErrors, showNoAnyError } }: ApplicationState) => {
  return {
    showWithElements,
    showWithErrors,
    showNoAnyError
  } as MappedStateProps
}

const mapDispatchToProps = {
  setShowWithElementsFilter,
  setShowWithErrorFilter,
  changePixelRangeFilter,
  changeShowWithNoAnyErrors,
};

export default compose<OwnProps>(
  connect(mapStateToProps, mapDispatchToProps),
  withStyles(styles)
)
  (FilterByErrorsButton);
