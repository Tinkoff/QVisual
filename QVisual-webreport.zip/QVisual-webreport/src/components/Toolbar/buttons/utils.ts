

export const pixelRangePrefix = 'Pixels ';
export function getRanges(ranges: number[]) {
  let start = 0;
  const res = [] as string[];
  for (let range of ranges) {
    res.push(`${pixelRangePrefix}${start}-${range}%`);
    start = range + 1;
  }
  return res;
}


export function memoize<T>(func: T, paramsToGetKeyFrom?): T {
  const memory = new Map<string, any>();
  function memoized(...args) {
    const key = JSON.stringify(paramsToGetKeyFrom ? paramsToGetKeyFrom(args) : args);
    if (memory.has(key))
      return memory.get(key);
    else {
      const res = (func as any)(...args);
      memory.set(key, res);
      return res;
    }
  }
  return memoized as any as T;
}

export function memoizeFirst<T>(func: T): T {
  return memoize(func, first => first);
}

export function memoizeLast<T>(func: T): T {
  return memoize(func, (args) => args[args.length - 1]);
}

