import React, { Component } from 'react';
import pt from 'prop-types';
import cn from 'classnames';
import { withStyles } from '@material-ui/core/styles';

// material components
import Button from '@material-ui/core/Button';

// material icons
import Reload from '@material-ui/icons/Autorenew';

const styles = () => ({
    rotate: {
        animation: 'rotating 1s linear infinite'
    },
    '@keyframes rotating': {
        from: {
            transform: 'rotate(0deg)'
        },
        to: {
            transform: 'rotate(360deg)'
        }
    }
});

class ReloadButton extends Component {
    constructor() {
        super();
        this.handleReload = this.handleReload.bind(this);
    }

    handleReload() {
        this.props.onClick();
    }

    render() {
        const { classes, className, reloading, disabled } = this.props;
        return (
            <Button
                component="a"
                size="small"
                disableRipple
                className={cn(className, reloading ? classes.rotate : '')}
                onClick={this.handleReload}
                disabled={disabled}
            >
                <Reload />
            </Button>
        );
    }
}

ReloadButton.propTypes = {
    classes: pt.object.isRequired,
    onClick: pt.func.isRequired,
    reloading: pt.bool.isRequired,
    className: pt.string,
    disabled: pt.bool
};

ReloadButton.defaultProps = {
    className: '',
    disable: false
};

export default withStyles(styles)(ReloadButton);
