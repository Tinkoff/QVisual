import React, { Component } from 'react';
import Tooltip from '@material-ui/core/Tooltip';
import pt from 'prop-types';
import cn from 'classnames';
import { withStyles } from '@material-ui/core/styles';

//icons
import DiffCtrl from '@material-ui/icons/Compare';
import ActualImg from '@material-ui/icons/CropOriginal';
import ExpectedImg from '@material-ui/icons/Photo';
import ZoomIn from '@material-ui/icons/ZoomIn';
import ActualPixels from '@material-ui/icons/Filter1';
import ExpectedPixels from '@material-ui/icons/Filter2';
import MoreVertIcon from '@material-ui/icons/MoreVert';
import FilterList from '@material-ui/icons/FilterList';

// material components
import AppBar from '@material-ui/core/AppBar';
import ToolbarContainer from '@material-ui/core/Toolbar';
import Button from '@material-ui/core/Button';
import Grid from '@material-ui/core/Grid';
import Snackbar from '@material-ui/core/Snackbar';
import Menu from '@material-ui/core/Menu';
import MenuItem from '@material-ui/core/MenuItem';
import IconButton from '@material-ui/core/IconButton';

// components
import FilterByEnv from '../FilterByEnv/FilterByEnv';
import DatePicker from '../FormFields/TextInput';
import ReloadButton from './buttons/ReloadButton.jsx';
import FilterByErrorsButton from './buttons/FilterByErrorsButton';
import { DISPLAY_TO_KEY, DISPLAYED_DIFF_TYPES } from '../Snapshot/constants/filters';
import StoryNavigation from './StoryNavigation';
import SnapshotNavigation from './SnapshotNavigation';

const styles = theme => ({
    wrapper: {
        alignItems: 'stretch'
    },
    wrapperItem: {
        display: 'flex',
        flexWrap: 'wrap'
    },
    toolbar: {
        backgroundColor: '#3E4756',
        paddingLeft: theme.spacing.unit * 1.5,
        paddingRight: theme.spacing.unit * 1.5,
        minHeight: '50px'
    },
    navigationToolbar: {
        extends: 'toolbar',
        borderBottom: '1px solid #DDDFE0',
        backgroundColor: '#EEF2F7',
        alignItems: 'center',
        justifyItems: 'flex-start',
        minHeight: '44px'
    },
    buttonCtrl: {
        color: '#75A3C6',
        padding: `${theme.spacing.unit}px ${theme.spacing.unit + 4}px`,
        minWidth: 0,
        minHeight: 0,
        fontSize: 12
    },
    notActive: {
        fill: '#DDDFE0',
        color: '#DDDFE0'
    },
    btnWrapper: {
        display: 'flex',
        flexFlow: 'row wrap',
        alignItems: 'center',
        justifyItems: 'stretch'
    },
    menuItem: {
        padding: 0,
        height: 'auto'
    },
    menuButton: {
        color: '#75A3C6',
        fontSize: 12,
        padding: `${theme.spacing.unit * 1.25}px ${theme.spacing.unit * 1.5}px`,
        justifyContent: 'left',
        width: '100%'
    },
    zoomWrapper: {
        display: 'flex',
        alignItems: 'center'
    },
    darkTooltip: {
        background: '#3E4756',
        fontSize: 12
    }
});

class Toolbar extends Component {
    state = {
        open: false
    };

    renderZoomCtrl() {
        const { classes, zoomLevel, disabled } = this.props;

        return (
            <span className={classes.btnWrapper}>
                <Button
                    className={classes.buttonCtrl}
                    onClick={this.props.handleZoomLevel(3)}
                    disabled={disabled}
                    size="small"
                    disableRipple
                >
                    <span
                        className={cn({
                            [classes.zoomWrapper]: true,
                            [classes.notActive]: zoomLevel !== 3
                        })}
                    >
                        <span>3</span>
                        <ZoomIn />
                    </span>
                </Button>

                <Button
                    className={classes.buttonCtrl}
                    onClick={this.props.handleZoomLevel(7)}
                    disabled={disabled}
                    size="small"
                    disableRipple
                >
                    <span
                        className={cn({
                            [classes.zoomWrapper]: true,
                            [classes.notActive]: zoomLevel !== 7
                        })}
                    >
                        <span>7</span>
                        <ZoomIn />
                    </span>
                </Button>
            </span>
        );
    }

    renderDiffCtrl() {
        const { classes, enableShowErrorFilter, disabled } = this.props;

        return (
            <span className={classes.btnWrapper}>
                {enableShowErrorFilter && <FilterByErrorsButton customClasses={classes} disabled={disabled} />}

                <Tooltip
                    title="Показать обводки элементов с ошибками"
                    placement="bottom-start"
                    classes={{ tooltip: classes.darkTooltip }}
                >
                    <Button
                        className={classes.buttonCtrl}
                        onClick={this.props.handleDiffShow}
                        disabled={disabled}
                        size="small"
                        disableRipple
                    >
                        <DiffCtrl
                            className={cn({
                                [classes.notActive]: this.props.disableDiffs
                            })}
                        />
                    </Button>
                </Tooltip>

                <Tooltip
                    title="Показать попиксельное сравнение на текущем скриншоте"
                    placement="bottom-start"
                    classes={{ tooltip: classes.darkTooltip }}
                >
                    <Button
                        className={classes.buttonCtrl}
                        onClick={this.props.handlePixelsShow}
                        disabled={disabled}
                        size="small"
                        disableRipple
                        data-type="actual"
                    >
                        <ActualPixels
                            className={cn({
                                [classes.notActive]: this.props.pixels !== 'actual'
                            })}
                        />
                    </Button>
                </Tooltip>

                <Tooltip
                    title="Показать попиксельное сравнение на эталонном скриншоте"
                    placement="bottom-start"
                    classes={{ tooltip: classes.darkTooltip }}
                >
                    <Button
                        className={classes.buttonCtrl}
                        onClick={this.props.handlePixelsShow}
                        disabled={disabled}
                        size="small"
                        disableRipple
                        data-type="expected"
                    >
                        <ExpectedPixels
                            className={cn({
                                [classes.notActive]: this.props.pixels !== 'expected'
                            })}
                        />
                    </Button>
                </Tooltip>
            </span>
        );
    }

    renderShowStateCtrl() {
        const { classes, visibility, disabled } = this.props;

        return (
            <span className={classes.btnWrapper}>
                <Tooltip
                    title="Показать текущий скриншот"
                    placement="bottom-start"
                    classes={{ tooltip: classes.darkTooltip }}
                >
                    <Button
                        className={classes.buttonCtrl}
                        onClick={this.props.handleVisibility('actual')}
                        disabled={disabled}
                        size="small"
                        disableRipple
                    >
                        <ActualImg className={visibility === 'actual' ? '' : classes.notActive} />
                    </Button>
                </Tooltip>
                <Tooltip
                    title="Показать эталонный скриншот"
                    placement="bottom-start"
                    classes={{ tooltip: classes.darkTooltip }}
                >
                    <Button
                        className={classes.buttonCtrl}
                        onClick={this.props.handleVisibility('expected')}
                        disabled={disabled}
                        size="small"
                        disableRipple
                    >
                        <ExpectedImg className={visibility === 'expected' ? '' : classes.notActive} />
                    </Button>
                </Tooltip>
                <Tooltip
                    title="Показать текущий и эталонный скриншоты"
                    placement="bottom-start"
                    classes={{ tooltip: classes.darkTooltip }}
                >
                    <Button
                        className={classes.buttonCtrl}
                        onClick={this.props.handleVisibility('all')}
                        disabled={disabled}
                        size="small"
                        disableRipple
                    >
                        <ActualImg className={visibility === 'all' ? '' : classes.notActive} />
                        <ExpectedImg className={visibility === 'all' ? '' : classes.notActive} />
                    </Button>
                </Tooltip>
            </span>
        );
    }

    renderDiffVisibilityCtrls = () => {
        const { classes, diffsVisibility, disabled, anchorEl } = this.props;

        return (
            <span className={classes.btnWrapper}>
                <Tooltip
                    title="Фильтровать по видимости элементов"
                    placement="bottom-start"
                    classes={{ tooltip: classes.darkTooltip }}
                >
                    <IconButton
                        className={classes.notActive}
                        aria-label="More"
                        aria-owns={anchorEl ? 'filter-menu' : null}
                        aria-haspopup="true"
                        onClick={this.props.handleOpenMenu}
                    >
                        <MoreVertIcon />
                    </IconButton>
                </Tooltip>
                <Menu
                    id="filter-menu"
                    anchorEl={anchorEl}
                    open={Boolean(anchorEl)}
                    onClose={this.props.handleCloseMenu}
                >
                    {/* https://github.com/mui-org/@material-ui/core/issues/5186 */}
                    <MenuItem key="placeholder" style={{ display: 'none' }} />
                    {Object.keys(DISPLAY_TO_KEY).map((filter, key) => (
                        <MenuItem key={`${filter}${key}`} className={classes.menuItem}>
                            <Button
                                onClick={this.props.handleDiffsVisibility(DISPLAY_TO_KEY[filter])}
                                disabled={disabled}
                                disableRipple
                                className={classes.menuButton}
                            >
                                <span
                                    className={
                                        diffsVisibility.includes(DISPLAY_TO_KEY[filter]) ? '' : classes.notActive
                                    }
                                >
                                    {filter}
                                </span>
                            </Button>
                        </MenuItem>
                    ))}
                </Menu>
            </span>
        );
    };

    renderDiffTypesCtrls = () => {
        const { classes, errorVisibility, disabled } = this.props;

        const ctrls = DISPLAYED_DIFF_TYPES.map((filter, key) => (
            <Button
                key={`${filter}${key}`}
                className={classes.buttonCtrl}
                onClick={this.props.handleErrorVisibility(filter)}
                disabled={disabled}
                size="small"
                disableRipple
            >
                <span className={errorVisibility.includes(filter) ? '' : classes.notActive}>{filter}</span>
            </Button>
        ));

        return <span className={classes.btnWrapper}>{ctrls}</span>;
    };

    render() {
        const {
            classes,
            enableRequestForm,
            enableEnvFilter,
            enableZoomCtrl,
            open,
            message,
            reloadSnapshot,
            enableReload,
            disabled,
            reloading,
            match
        } = this.props;

        return (
            <AppBar>
                <ToolbarContainer className={classes.toolbar}>
                    <Grid container spacing={0}>
                        <Grid item xs={12} className={classes.wrapperItem}>
                            {enableEnvFilter && (
                                <span className={classes.btnWrapper}>
                                    <FilterByEnv disabled={disabled} />
                                </span>
                            )}

                            {enableZoomCtrl && this.renderZoomCtrl()}
                            {this.renderDiffCtrl()}
                            {this.renderShowStateCtrl()}
                            {this.renderDiffTypesCtrls()}
                            {this.renderDiffVisibilityCtrls()}

                            {enableReload && (
                                <Tooltip
                                    title="Обновить данные отчета"
                                    placement="bottom-start"
                                    classes={{ tooltip: classes.darkTooltip }}
                                >
                                    <span className={classes.btnWrapper}>
                                        <ReloadButton
                                            customClasses={classes}
                                            className={classes.notActive}
                                            onClick={reloadSnapshot}
                                            reloading={reloading}
                                            disabled={disabled}
                                        />
                                    </span>
                                </Tooltip>
                            )}

                            {enableRequestForm && (
                                <form
                                    id="requests"
                                    action=""
                                    onSubmit={this.props.handleRequest}
                                    className={classes.btnWrapper}
                                >
                                    <DatePicker name="actualDate" placeholder={'Actual date'} />
                                    <DatePicker name="expectedDate" placeholder={'Expected date'} />
                                    <Button type={'submit'}>Go</Button>
                                </form>
                            )}
                        </Grid>
                    </Grid>
                </ToolbarContainer>
                <ToolbarContainer className={classes.navigationToolbar}>
                    <StoryNavigation />
                </ToolbarContainer>
                <ToolbarContainer className={classes.navigationToolbar}>
                    <SnapshotNavigation match={match} />
                </ToolbarContainer>
                <Snackbar
                    anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
                    open={open}
                    onClose={this.props.handleErrorClose}
                    ContentProps={{
                        'aria-describedby': 'err-msg-id'
                    }}
                    message={<span id="err-msg-id">{message}</span>}
                />
            </AppBar>
        );
    }
}

Toolbar.propTypes = {
    classes: pt.object.isRequired,
    disabled: pt.bool,
    reloading: pt.bool,
    enableRequestForm: pt.bool,
    open: pt.bool,
    message: pt.string,
    // show\hide pixels diff
    handlePixelsShow: pt.func.isRequired,
    pixels: pt.string.isRequired,
    // show\hide diffs
    disableDiffs: pt.bool.isRequired,
    // filter for visibility of diffs
    visibility: pt.string.isRequired,
    // filter for display attribute
    diffsVisibility: pt.array.isRequired,
    // filter for diff attribute
    errorVisibility: pt.array.isRequired,
    // filter for browser attribute
    enableEnvFilter: pt.bool,
    // snapshots has errors
    enableShowErrorFilter: pt.bool,
    // zoom
    enableZoomCtrl: pt.bool,
    zoomLevel: pt.number.isRequired,
    // reloading
    enableReload: pt.bool,
    // menu anchorEl
    anchorEl: pt.object,
    // handlers
    handleRequest: pt.func.isRequired,
    handleErrorClose: pt.func.isRequired,
    handleZoomLevel: pt.func.isRequired,
    handleDiffShow: pt.func.isRequired,
    handleVisibility: pt.func.isRequired,
    handleDiffsVisibility: pt.func.isRequired,
    handleErrorVisibility: pt.func.isRequired,
    handleOpenMenu: pt.func.isRequired,
    handleCloseMenu: pt.func.isRequired,
    reloadSnapshot: pt.func.isRequired
};

Toolbar.defaultProps = {
    anchorEl: null,
    disabled: false,
    reloading: false,
    enableRequestForm: false,
    enableEnvFilter: false,
    enableShowErrorFilter: false,
    enableZoomCtrl: false,
    enableReload: false,
    open: false,
    message: '',
    match: {
        params: {}
    }
};

export default withStyles(styles)(Toolbar);
