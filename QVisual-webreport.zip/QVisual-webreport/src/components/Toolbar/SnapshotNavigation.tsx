import * as React from 'react';
import { compose } from 'redux';
import { connect } from 'react-redux';
import { withStyles, WithStyles, Tabs, Tab } from '@material-ui/core';
import { StyleRules } from '@material-ui/core/styles';
import { selectTab } from '../reducers/storyReducer';
import { ApplicationState, Snapshot } from '../../types';
import { getReactKey, createUrl } from '../../utils/snapshot';
import SnapshotInfo from '../Snapshot/SnapshotInfo';
import OpenInNew from '@material-ui/icons/OpenInNew';
import { Link } from 'react-router-dom';
import path from '@tinkoff/utils/object/path';
import pathOr from '@tinkoff/utils/object/pathOr';

interface DispatchFunctions {
  selectTab: typeof selectTab;
}

interface MapStateProps {
  selectedSnapshot: number;
  actualDate: string;
  expectedDate: string;
  snapshots: Snapshot[];
  storyName;
  stateName;
}

interface OwnProps {
  match: any;
}

const styles = () => ({
  wrapper: {
    width: '100%'
  },
  tabs: {
    '& button': {
      height: 'auto'
    }
  },
  link: {
    color: '#DDDFE0',
    '&:hover': {
      color: '#3E4756',
    },
    fontSize: 24
  },
  tabLink: {
    '& svg:hover': {
      fill: '#3E4756'
    }
  },
  tabInfo: {
    display: 'flex',
    justifyContent: 'flex-start'
  },
  tabOverride: {
    maxWidth: 'initial',
    '&>*': {
      alignItems: 'initial',
    }
  }
} as StyleRules);

class SnapshotNavigation extends React.Component<MapStateProps & DispatchFunctions & WithStyles<typeof styles>> {

  getTabs = () => {
    const { stateName, classes, storyName, actualDate, expectedDate, snapshots } = this.props;
    return snapshots.map((snapshot, key) => {
      const url = createUrl(storyName, stateName, snapshot, actualDate, expectedDate);
      const Label = (
        <span className={classes.tabInfo}>
          <SnapshotInfo snapshot={snapshot} />
          <span className={classes.tabLink}>
            <Link to={url} key={`link-${key}`} className={classes.link} target="_blank">
              <OpenInNew fontSize='inherit' color="inherit" />
            </Link>
          </span>
        </span>
      );
      return <Tab className={classes.tabOverride} key={`${getReactKey(snapshot)}-tab`} label={Label} disableRipple />
    });
  }

  render() {
    const { classes, selectedSnapshot } = this.props;
    const tabs = this.getTabs();
    return <div className={classes.wrapper}>
      <Tabs
        className={classes.tabs}
        value={selectedSnapshot}
        onChange={this.handleTabChange}
        indicatorColor="primary"
        textColor="primary"
        scrollButtons="off"
        scrollable
      >
        {tabs}
      </Tabs>
    </div>;
  }

  handleTabChange = (_, selected) => {
    this.props.selectTab(selected);
  }
}

const getName = path(['name']);
const mapStateToProps = ({ stories: { filteredStories, currentSnapshotIndex, currentStateIndex, currentStoryIndex } }: ApplicationState, { match }: OwnProps): MapStateProps => {
  const story = filteredStories[currentStoryIndex];
  const storyName = getName(story);

  const state = pathOr(['states', currentStateIndex], { snapshots: [] }, story);
  const stateName = getName(state);

  const snapshots = pathOr(['snapshots'], [], state);
  
  return {
    selectedSnapshot: currentSnapshotIndex,
    stateName,
    storyName,
    snapshots,
    actualDate: match.params.actual || '',
    expectedDate: match.params.expected || '',
  };
}

const mapDispatchToProps: DispatchFunctions = {
  selectTab
};

export default compose<OwnProps>(connect(mapStateToProps, mapDispatchToProps), withStyles(styles))(SnapshotNavigation);
