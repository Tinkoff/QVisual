import * as React from 'react';
import { withStyles, WithStyles, StyleRules } from '@material-ui/core/styles';
import IconButton from '@material-ui/core/IconButton';
import ChevronLeft from '@material-ui/icons/ChevronLeft';
import ChevronRight from '@material-ui/icons/ChevronRight';
import { Button } from '@material-ui/core';
import { compose } from 'redux';
import { ApplicationState, State, Story } from '../../types';
import { connect } from 'react-redux';
import { moveCurrentStateIdx, moveCurrentStoryIdx } from '../reducers/storyReducer';
import { switchBoard } from '../reducers/boardReducer';
import path from '@tinkoff/utils/object/path';
import pathOr from '@tinkoff/utils/object/pathOr';

interface MapStateProps {
  state: State,
  story: Story,
  canMoveStoryLeft: boolean,
  canMoveStoryRight: boolean,
  canMoveStateLeft: boolean,
  canMoveStateRight: boolean,
}

interface DispatchFunctions {
  moveCurrentStoryIdx: (moveTo: number) => void,
  moveCurrentStateIdx: (moveTo: number) => void,
  switchBoard: () => void,
}

const cn = require('classnames');
const styles = {
  wrapper: {
    display: 'flex',
    alignItems: 'center',
    width: '100%',
    '&>div': {
      flex: 1,
    }
  },
  testCaseId: {
    marginRight: 10,
    color: '#9299A2',
    fontSize: 12
  }
};

class StoryNavigation extends React.Component<DispatchFunctions & MapStateProps & WithStyles<typeof styles>> {
  render() {
    const { classes, state, story, switchBoard,
      canMoveStoryLeft, canMoveStoryRight, canMoveStateLeft, canMoveStateRight
    } = this.props;

    return <div className={classes.wrapper}>
      <Panel
        canMoveLeft={canMoveStoryLeft}
        canMoveRight={canMoveStoryRight}
        onLeftClick={this.moveStoryLeft}
        onRightClick={this.moveStoryRight}
        onTitleClick={switchBoard}
        caption={path(['name'], story)}
        error={story.failed} />
      <Panel
        canMoveLeft={canMoveStateLeft}
        canMoveRight={canMoveStateRight}
        onLeftClick={this.moveStateLeft}
        onRightClick={this.moveStateRight}
        onTitleClick={switchBoard}
        caption={<StateDescription testCaseClassName={classes.testCaseId} state={state} />}
        error={state.failed} />
    </div>
  }

  moveTo = (fn, to: number) => () => fn(to);

  moveStateRight = this.moveTo(this.props.moveCurrentStateIdx, 1);
  moveStateLeft = this.moveTo(this.props.moveCurrentStateIdx, -1);
  moveStoryRight = this.moveTo(this.props.moveCurrentStoryIdx, 1);
  moveStoryLeft = this.moveTo(this.props.moveCurrentStoryIdx, -1);
}

export const StateDescription = ({ testCaseClassName, state = {} as State }: { testCaseClassName?: string, state: State }) => {
  return <span>
    <span className={testCaseClassName}>
      {state.snapshotTestCaseId}
    </span>
    {state.name}
  </span>
};

interface IPanelProps {
  caption?: React.ReactNode,
  onLeftClick?: () => void,
  onRightClick?: () => void,
  onTitleClick?: () => void,
  canMoveLeft: boolean,
  canMoveRight: boolean,
  error: boolean
}

const panelStyles = {
  wrapper: {
    display: 'flex',
    alignItems: 'center'
  },
  smallIcon: {
    width: '32px',
    height: '32px'
  },
  caption: {
    flex: 1,
    justifyContent: 'flex-start',
    fontWeight: 'bolder',
    fontSize: 14,
    textTransform: 'initial',
    color: '#3E4756'
  },
  errorCaption: {
    flex: 1,
    justifyContent: 'flex-start',
    fontWeight: 'bolder',
    fontSize: 14,
    textTransform: 'initial',
    color: '#CD5C5C'
  }
} as StyleRules;

const Panel = withStyles(panelStyles)<IPanelProps>(
  class Panel extends React.Component<IPanelProps & WithStyles<typeof panelStyles>> {
    render() {
      const { caption, onLeftClick, onRightClick, onTitleClick, classes, canMoveLeft, canMoveRight, error } = this.props;
      return (
        <div className={classes.wrapper}>
          <IconButton className={classes.smallIcon} disabled={!canMoveLeft} onClick={onLeftClick}>
            <ChevronLeft />
          </IconButton>
          <Button className={error ? classes.errorCaption : classes.caption} onClick={onTitleClick}>
            {caption || ''}
          </Button>
          <IconButton className={classes.smallIcon} disabled={!canMoveRight} onClick={onRightClick}>
            <ChevronRight />
          </IconButton>
        </div>
      )
    }
  }
);

const mapStateToProps = ({ stories: { filteredStories, currentStateIndex, currentStoryIndex } }: ApplicationState): MapStateProps => {
  const canMoveStoryLeft = currentStoryIndex > 0;
  const canMoveStoryRight = currentStoryIndex + 1 < filteredStories.length;
  const canMoveStateLeft = currentStateIndex > 0;

  const story = filteredStories[currentStoryIndex] || { states: [] } as Story;
  const state = pathOr(['states', currentStateIndex], {}, story);
  const canMoveStateRight = currentStateIndex + 1 < story.states.length;

  return {
    state,
    story,
    canMoveStoryLeft,
    canMoveStoryRight,
    canMoveStateLeft,
    canMoveStateRight,
  };
}

const mapDispatchToProps: DispatchFunctions = {
  moveCurrentStateIdx,
  moveCurrentStoryIdx,
  switchBoard
};

export default compose<{}>(connect(mapStateToProps, mapDispatchToProps), withStyles(styles))(StoryNavigation);
