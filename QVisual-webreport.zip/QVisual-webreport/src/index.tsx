import * as React from 'react';
import * as ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import { ConnectedRouter } from 'react-router-redux';
import App from './components/App/App';
import store, { history } from './store';

import 'typeface-lato';
import './index.css';
import { createMuiTheme, MuiThemeProvider } from '@material-ui/core/styles';

const theme = createMuiTheme({
    typography: {
        fontFamily: '"Lato", sans-serif'
    },
    overrides: {
        MuiPaper: {
            root: {
                backgroundColor: '#3E4756',
                borderRadius: '5px !important'
            },
            elevation4: {
                boxShadow: 'none'
            },
            rounded: {
                borderRadius: 0
            }
        },
        MuiTabs: {
            indicator: {
                backgroundColor: '#75A3C6',
                height: 3
            }
        },
        MuiListItem: {
            button: {
                '&:hover': {
                    backgroundColor: 'rgba(0, 0, 0, 0.04)'
                }
            }
        },
        MuiInput: {
            underline: {
                '&:before': {
                    borderBottom: '0px solid #000000'
                },
                '&:after': {
                    borderBottom: '2px solid #75A3C6'
                }
            }
        },
        MuiFormLabel: {
            root: {
                color: '#9299A2',
                fontSize: 14,
                '&:focused': {
                    color: '#75A3C6'
                }
            },
            focused: {
                "&$focused": {
                    color: '#75A3C6'
                }
            }
        }
    }
});

ReactDOM.render(
    <Provider store={store}>
        <ConnectedRouter history={history}>
            <MuiThemeProvider theme={theme}>
                <App />
            </MuiThemeProvider>
        </ConnectedRouter>
    </Provider>,
    document.getElementById('root')
);
