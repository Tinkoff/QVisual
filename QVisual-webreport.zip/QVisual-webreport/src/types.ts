export interface ApplicationState {
  stories: StoriesState;
  board: BoardState;
  storiesFilter: StoriesFilterState;
  snapshot: SnapshotState;
}

export interface StoriesState {
  stories: Story[];
  filteredStories: Story[];
  currentStoryIndex: number;
  currentStateIndex: number;
  currentSnapshotIndex: number;
}

export type SnapshotStatistics = Record<string, SnapshotStatistic>;

export type SnapshotStatistic = {
  pixels: number;
  total: number;
  errorsQuantity: number;
  error: any;
};

export interface SnapshotState {
  zoom: number;
  zoomEnabled: boolean;
}

export interface BoardState {
  showSnapshot: boolean;
}

export interface Story {
  id: string;
  name: string;
  failed?: boolean;
  states: State[];
}

export interface State {
  id: string;
  name: string;
  snapshotTestCaseId: string;
  failed?: boolean;
  snapshots: Snapshot[];
}

export interface Snapshot {
  id: string;
  server: Difference;
  branch: Difference;
  commit: Difference;
  error: string;
  browser: Browser;
  diffPercentage: number;
  images: Difference;
  testcaseId: string;
  elements: Element[];
  pixels?: number;
  failed?: boolean;
}

export interface Difference {
  actual: string;
  expected: string;
}

export interface Browser {
  device: string;
  osName: string;
  osVersion: string;
  browserName: string;
  browserNameMobile: string;
  browserVersion: string;
  resolution: string;
  retina: boolean;
}

export interface Element {
  diff: string[];
  name: string;
  display: string;
  image: string;
  text: Result;
  css: Record<string, Result>;
  attributes: Record<string, Result>;
  area: Area;
}

export interface Result {
  actual: string | number;
  expected: string | number
  diff: string | number;
}

export interface Area {
  left: Result;
  top: Result;
  right: Result;
  bottom: Result;
  width: Result;
  height: Result;
}

export interface FetchedState {
  state: string;
  snapshots: Snapshot[];
}
export interface FetchedStory {
  story: string;
  states: FetchedState[];
}

// TODO: добавить строковые константы из filter.js
export type StoriesFilterState = {
  disableDiffs: boolean,
  pixels: string,
  visibility: string,
  diffsVisibility: string[],
  errorVisibility: string[],
  environment: string[],
  browser: string[],
  resolutions: string[],
  selectedDiff: string,
  showNoAnyError: boolean,
} & StatsFilterKeys;

export type StatsFilterKeys = {
  pixelRanges: (number[])[],
  showWithErrors: boolean,
  showWithElements: boolean,
}