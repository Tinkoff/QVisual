export const findStateByTestcaseId = (states, testcaseId) =>
    states.find(s => !!s.snapshots.find(snap => snap.testcaseId === testcaseId));
export const findStoryByTestcaseId = (stories, testcaseId) =>
    stories.find(s => !!findStateByTestcaseId(s.states, testcaseId));
