const api = process.env.REACT_APP_API || 'http://localhost:8081';

export default (method, data, { throwOnErrors = true } = {}) => {
    const dataObjToQuery = dataObj =>
        `?${Object.keys(dataObj)
            .map(key => {
                return `${encodeURIComponent(key)}=${data[key]}`;
            })
            .join('&')}`;

    const query = typeof data === 'object' ? dataObjToQuery(data) : typeof data === 'string' ? data : '';

    return fetch(`${api}${method}${query}`)
        .then(resp => resp.json())
        .then(respObj => {
            if (throwOnErrors && !respObj) {
                throw new Error(`${respObj.resultCode}: ${respObj.errorMessage}`);
            }

            return respObj;
        });
};
