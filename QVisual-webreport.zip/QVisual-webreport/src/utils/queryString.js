const queryString = qs => {
    let query = qs.substr(1);
    let result = {};

    if (query) {
        query.split('&').forEach(function(part) {
            let [key, value = ''] = part.split('=');
            result[key] = decodeURIComponent(value);
        });
    }

    return result;
};

export default queryString;
