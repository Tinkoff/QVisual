function intersection(firstArray = [], secondArray = []) {
    return firstArray.filter(item => secondArray.indexOf(item) !== -1);
}

export default intersection;
