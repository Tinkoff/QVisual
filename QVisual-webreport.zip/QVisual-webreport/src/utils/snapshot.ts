import { Snapshot, Story, State } from "../types";
import createUrlTo from "./createUrl";

/*
    Порядок сортировки (по приоритетам):
    1. Операционная систсема: Linux, Mac, Windows
    2. Браузер: chrome, safari
    3. Версия браузера
    4. Ширина экрана
    Поэтому порядок элементов в массиве priorities имеет значение.
*/
const priorities = ['osName', 'browserName', 'browserVersion', 'resolution'];
export const byPriorities = (firstSnapshot: Snapshot, secondSnapshot: Snapshot) => {
  const firstBrowser = firstSnapshot.browser;
  const secondBrowser = secondSnapshot.browser;
  const firstBrowserWidth = Number(firstBrowser.resolution.split('x')[0]);
  const secondBrowserWidth = Number(secondBrowser.resolution.split('x')[0]);

  // Найдем свойство c максимальным приоритетом, которое не совпадает.
  const unequalProperty = priorities.find(priority => {
    return firstBrowser[priority] !== secondBrowser[priority];
  });

  // В зависимости от того, какое это свойство, вернем результат сравнения
  // В случае osName сравним osName.upperCase, т.к. в UI отображается именно uppercase
  switch (unequalProperty) {
    case 'osName':
      return firstBrowser.osName.toUpperCase() > secondBrowser.osName.toUpperCase() ? 1 : -1;
    case 'browserVersion':
      return Number(firstBrowser.browserVersion) > Number(secondBrowser.browserVersion) ? -1 : 1;
    case 'resolution':
      return firstBrowserWidth > secondBrowserWidth ? -1 : 1;
    default:
      return firstBrowser[unequalProperty] > secondBrowser[unequalProperty] ? 1 : -1;
  }
};

export const getReactKey = (snapshot: Snapshot) =>
  btoa(snapshot.images.actual + snapshot.images.expected + snapshot.browser.resolution + snapshot.browser.browserName);


export const createUrl = (story: string, state: string, {
  browser: {
    browserName,
    browserVersion,
    device,
    osName,
    osVersion,
    resolution,
    retina
  }
}: Snapshot, actualDate, expectedDate) => {
  const url = createUrlTo(
    '/story/', {
      story,
      state,
      browserName,
      browserVersion,
      device,
      osName,
      osVersion,
      resolution,
      retina
    });
  return actualDate && expectedDate
    ? `/actual/${actualDate}/expected/${expectedDate}${url}`
    : url;
}

export const getInfo = (snapshot: Snapshot) => {
  if (!snapshot || !snapshot.browser) {
    return null;
  }

  const { browser } = snapshot;
  const retina = browser.retina ? `, retina` : '';
  const resolution = browser.resolution ? `(${browser.resolution}${retina})` : '';
  const deviceInfo = `${browser.device} ${browser.osName} ${browser.osVersion}`;
  const browserInfo = `${browser.browserName} ${browser.browserVersion} ${
    resolution
    }`;

  return {
    deviceInfo,
    browserInfo
  };
};

export const findCurrents = (stories: Story[], {
  story: storyName, state: stateName,
  browserName,
  browserVersion,
  device,
  osName,
  osVersion,
  resolution,
  retina,
}): {
    snapshot?: Snapshot,
    state?: State,
    story?: Story,
  } => {
  retina = retina === 'true';

  const story = stories.find(st => st.name === storyName);
  if (!story)
    return {};

  const state = story.states.find(st => st.name === stateName);
  if (!state)
    return {};

  const currentSnapshot = state.snapshots.find(
    s =>
      s.browser.browserName === browserName &&
      s.browser.browserVersion === browserVersion &&
      s.browser.device === device &&
      s.browser.osName === osName &&
      s.browser.osVersion === osVersion &&
      s.browser.resolution === resolution &&
      s.browser.retina === retina
  );

  return {
    snapshot: currentSnapshot,
    state,
    story,
  }
}