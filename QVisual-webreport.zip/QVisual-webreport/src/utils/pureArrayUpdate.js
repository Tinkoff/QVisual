const pureArrayUpdate = (filterState, visibility) => {
    const found = filterState.indexOf(visibility);
    let filters = filterState.slice();

    if (found > -1) {
        filters = [...filterState.slice(0, found), ...filterState.slice(found + 1)];
    } else {
        filters.push(visibility);
    }

    return filters;
};

export default pureArrayUpdate;
