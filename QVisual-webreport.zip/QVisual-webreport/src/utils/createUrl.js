const createUrl = (url, query) => {
    return `${url}?${Object.entries(query)
        .filter(([key, value]) => value !== undefined)
        .map(([key, value]) => {
            return `${encodeURIComponent(key)}=${value}`;
        })
        .join('&')}`;
};

export default createUrl;
