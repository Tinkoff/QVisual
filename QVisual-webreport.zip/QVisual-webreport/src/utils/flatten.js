export default arr => [].concat.apply([], arr);
