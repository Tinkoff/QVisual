import { DISPLAY_TO_KEY, DISPLAYED_DIFF_TYPES } from '../components/Snapshot/constants/filters';
import { SnapshotStatistic, Snapshot } from '../types';

export const DISPLAY_TYPES = DISPLAYED_DIFF_TYPES.concat(
    Object.keys(DISPLAY_TO_KEY).filter(type => type !== 'displayed')
).concat(['pixels', 'total', 'error', 'errorsQuantity']);

export const createStats = () => {
    const statsObj = {} as SnapshotStatistic;

    DISPLAY_TYPES.forEach(display => {
        statsObj[display] = 0;
    });

    return statsObj;
};

export const isStatFailed = (stat: SnapshotStatistic) => stat.pixels || stat.errorsQuantity || stat.total


export const getSnapshotStats = (snapshot: Snapshot, totalStats = createStats()) => {
    snapshot.elements.forEach(attr => {
        if (!attr) {
            return;
        }
        attr.diff.forEach(type => {
            if (totalStats[type] >= 0) {
                totalStats[type] += 1;
            }
        });

        if (totalStats[attr.display] !== undefined) {
            totalStats[attr.display] += 1;
        }
    });

    totalStats.pixels += snapshot.pixels ? 1 : 0;
    totalStats.total += snapshot.elements.length;
    totalStats.errorsQuantity += +!!snapshot.error;
    totalStats.error = snapshot.error;

    return totalStats;
};

const getSnapshotsStats = (snapshots, totalStats) => {
    snapshots.forEach(snapshot => {
        getSnapshotStats(snapshot, totalStats);
    });
};

export const getStatesStats = (states, totalStoryStat) => {
    const stats = [];

    states.forEach(state => {
        const totalStateStat = createStats();

        getSnapshotsStats(state.snapshots, totalStateStat);

        DISPLAY_TYPES.forEach(disp => {
            totalStoryStat[disp] += totalStateStat[disp];
        });

        stats.push({ totalStats: totalStateStat });
    });

    return stats;
};

export const getStats = statistics =>
    DISPLAY_TYPES.reduce((result, type) => {
        result[type] = statistics.totalStats[type];

        return result;
    }, {});
